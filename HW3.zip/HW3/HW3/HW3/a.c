/*
 * HW3.c
 *
 * Created: 7/6/2018 4:31:14 PM
 * Author : Kadeem
 * This program will configure a timer/counter to trigger an overflow interrupt every 100 ms. When this happens, pin 0 on I/O port C will be toggled.
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

#define Prescaler  0x07 //Set the prescaler value to divide the clock input to TCC0 by 1024
#define Top  195 //Set the maximum count value to 195
#define LowLvlInt 0x01 


int main(void)
{
    //Set Pin0 on Port C as an output
	PORTC_DIRSET = 0xFF;
	PORTC_OUT = 0xFF;
	
	//Initialize the counter
	TCC0INIT();
    while (1) 
    {
    }
}

void TCC0INIT(void)
{
	TCC0_PER = Top;
	TCC0_CNT = 0;
	TCC0_INTCTRLA = LowLvlInt;
	PMIC_CTRL = LowLvlInt;
	TCC0_CTRLA = Prescaler;
	sei(); //Enable global interrupts
	
}

ISR(TCC0_OVF_vect)
{
	TCC0_INTFLAGS = 1;
	PORTC_OUTTGL = 1;
}