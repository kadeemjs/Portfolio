/*
 * hw3_1b.c
 *
 * Created: 7/6/2018 6:18:15 PM
 *  Author: Kadeem
 */

#include <avr/io.h>
#include <avr/interrupt.h>

#define BSCALE 0x0A //-6
#define BSEL 75
#define LowLvlInt 0x01
#define Blue ~(1<<6)
#define NotBlue (1<<6)
#define Off 0xFF

void usart_d0_init(void);
void usart_d0_out_char(char d);
char usart_d0_in_char(void);

int main(void)
{
	//Initialize the USART
	usart_d0_init();
	//string Input;
	char volatile d = 0;
	while (1)
	{
		d = usart_d0_in_char();
		usart_d0_out_char(d);
		if ((d == 'B')||(d == 'b'))
		{
			d = usart_d0_in_char();
			usart_d0_out_char(d);
			if ((d == 'L')||(d == 'l'))
			{
				d = usart_d0_in_char();
				usart_d0_out_char(d);
				if ((d == 'U')||(d == 'u'))
				{
					d = usart_d0_in_char();
					usart_d0_out_char(d);
					if ((d == 'E')||(d == 'e'))
					{
						PORTD.OUTTGL = PIN6_bm;
					}
				}
			}
		}
	}
}

void usart_d0_init(void)
{
	PORTD.DIRCLR = PIN2_bm; //Set the TX line as an input
	PORTD.DIRSET = PIN3_bm|NotBlue; //Set the RX line as an output
	PORTD.OUT = PIN2_bm|PIN3_bm|PIN6_bm; //Set the pins to be high
	USARTD0.CTRLA = 0; //Disable interrupts
	USARTD0.CTRLC = USART_CMODE_ASYNCHRONOUS_gc|USART_PMODE_ODD_gc|USART_CHSIZE_8BIT_gc; //Allow for asynchronous data transfer, odd parity, 1 start bit, and 8 bit data
	USARTD0.BAUDCTRLA = (uint8_t)BSEL;
	USARTD0.BAUDCTRLB = (uint8_t)( (BSCALE << 4)|(BSEL>>8) );
	USARTD0.CTRLB = USART_RXEN_bm|USART_TXEN_bm; //Enable the transmitter and the receiver
}

void usart_d0_out_char(char d)
{
	while (1)
	{
		if ((USARTD0.STATUS & PIN5_bm) == PIN5_bm)
		{
			USARTD0.DATA = d;
			break;
		}
	}
}

char usart_d0_in_char(void)
{
	char volatile letter = 0;
	while (1) 
	{
		if ((USARTD0.STATUS & PIN7_bm) == PIN7_bm)
		{
			letter = USARTD0.DATA;
			break;
		}
	}
	return letter;
}