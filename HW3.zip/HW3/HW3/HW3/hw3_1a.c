/*
 * hw3_1a.c
 *
 * Created: 7/6/2018 6:16:55 PM
 *  Author: Kadeem
 */ 

#include <avr/io.h>

#define BSCALE 0x0A //-6
#define BSEL 75

void usart_d0_init(void);
void usart_d0_out_char(char d);

int main(void)
{
	//Initialize the USART
	usart_d0_init();
	char d = 'U';
	while (1)
	{
		usart_d0_out_char(d);
	}
}

void usart_d0_init(void) 
{
	PORTD.DIRCLR = PIN2_bm;
	PORTD.DIRSET = PIN3_bm;
	PORTD.OUT = PIN2_bm|PIN3_bm;
	USARTD0.CTRLA = 0;
	USARTD0.CTRLC = USART_CMODE_ASYNCHRONOUS_gc|USART_PMODE_ODD_gc|USART_CHSIZE_8BIT_gc;
	USARTD0.BAUDCTRLA = (uint8_t)BSEL;
	USARTD0.BAUDCTRLB = (uint8_t)( (BSCALE << 4)|(BSEL>>8) );
	USARTD0.CTRLB = USART_TXEN_bm;
}

void usart_d0_out_char(char d)
{
	while (1)
	{
		if ((USARTD0.STATUS & PIN5_bm) == PIN5_bm)
		{
			USARTD0.DATA = d;
			break;
		}
	}
}