/*
 * lab6_5_test.c
 *
 * Created: 7/26/2018 6:58:32 PM
 *  Author: Kadeem
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "DAC.h"
#include "USART.h"

extern void clock_init(void);
void tcc0_init(void);
void tcc1_init(void);
void tce0_init(void);
void DMA_init(void);
//Lookup table values
const int sine[256] = //Lookup table of 256 values for sine wave
{
	500, 512, 525, 537, 549, 561, 574, 586, 598, 610, 622, 634, 646, 657, 669, 681, 692, 703, 715, 726, 737, 747, 758, 768, 779, 789, 799, 809, 818, 828, 837, 846, 855, 863, 872, 880, 888, 895, 903, 910, 917, 923, 930, 936, 942, 948, 953, 958, 963, 967, 972, 976, 979, 983, 986, 988, 991, 993, 995, 997, 998, 999, 1000, 1000, 1000, 1000, 999, 998, 997, 996, 994, 992, 990, 987, 984, 981, 977, 974, 969, 965, 960, 956, 950, 945, 939, 933, 927, 920, 913, 906, 899, 891, 884, 876, 867, 859, 850, 841, 832, 823, 813, 804, 794, 784, 774, 763, 753, 742, 731, 720, 709, 698, 686, 675, 663, 652, 640, 628, 616, 604, 592, 580, 568, 555, 543, 531, 518, 506, 494, 482, 469, 457, 445, 432, 420, 408, 396, 384, 372, 360, 348, 337, 325, 314, 302, 291, 280, 269, 258, 247, 237, 226, 216, 206, 196, 187, 177, 168, 159, 150, 141, 133, 124, 116, 109, 101, 94, 87, 80, 73, 67, 61, 55, 50, 44, 40, 35, 31, 26, 23, 19, 16, 13, 10, 8, 6, 4, 3, 2, 1, 0, 0, 0, 0, 1, 2, 3, 5, 7, 9, 12, 14, 17, 21, 24, 28, 33, 37, 42, 47, 52, 58, 64, 70, 77, 83, 90, 97, 105, 112, 120, 128, 137, 145, 154, 163, 172, 182, 191, 201, 211, 221, 232, 242, 253, 263, 274, 285, 297, 308, 319, 331, 343, 354, 366, 378, 390, 402, 414, 426, 439, 451, 463, 475, 488, 500
};

const int sawtooth[256] = //Lookup table of 256 values for sawtooth wave
{
	0, 4, 8, 12, 16, 20, 24, 27, 31, 35, 39, 43, 47, 51, 55, 59, 63, 67, 71, 75, 78, 82, 86, 90, 94, 98, 102, 106, 110, 114, 118, 122, 125, 129, 133, 137, 141, 145, 149, 153, 157, 161, 165, 169, 173, 176, 180, 184, 188, 192, 196, 200, 204, 208, 212, 216, 220, 224, 227, 231, 235, 239, 243, 247, 251, 255, 259, 263, 267, 271, 275, 278, 282, 286, 290, 294, 298, 302, 306, 310, 314, 318, 322, 325, 329, 333, 337, 341, 345, 349, 353, 357, 361, 365, 369, 373, 376, 380, 384, 388, 392, 396, 400, 404, 408, 412, 416, 420, 424, 427, 431, 435, 439, 443, 447, 451, 455, 459, 463, 467, 471, 475, 478, 482, 486, 490, 494, 498, 502, 506, 510, 514, 518, 522, 525, 529, 533, 537, 541, 545, 549, 553, 557, 561, 565, 569, 573, 576, 580, 584, 588, 592, 596, 600, 604, 608, 612, 616, 620, 624, 627, 631, 635, 639, 643, 647, 651, 655, 659, 663, 667, 671, 675, 678, 682, 686, 690, 694, 698, 702, 706, 710, 714, 718, 722, 725, 729, 733, 737, 741, 745, 749, 753, 757, 761, 765, 769, 773, 776, 780, 784, 788, 792, 796, 800, 804, 808, 812, 816, 820, 824, 827, 831, 835, 839, 843, 847, 851, 855, 859, 863, 867, 871, 875, 878, 882, 886, 890, 894, 898, 902, 906, 910, 914, 918, 922, 925, 929, 933, 937, 941, 945, 949, 953, 957, 961, 965, 969, 973, 976, 980, 984, 988, 992, 996, 1000
};

int volatile charReceived = 0;

int main(void)
{
	uint8_t volatile waveform = 0x37;
	char volatile usartInput = 0;
	int volatile swap = 0;
	PORTC.DIRSET = PIN7_bm; //Set pin7 on PORTC to be an output
	PORTC.OUTSET = PIN7_bm; //Set the pin to be high, so that the Audio Amp will never shut down
	clock_init(); //Set the clock to 32 MHz
	DAC_init(); //Initialize the DAC
	DMA_init(); //Initialize DMA
	usart_d0_init(); //Initialize the USART
	tcc0_init();
	//Use second timer to turn off DAC
	//Turn off timer on proper key press and turn on timer after key press
	tcc1_init();
	//Use third timer to break out of infinite loop that occasionally occurs
	tce0_init();
	sei();
	while(1)
	{
		if(charReceived == 0)
		{
			TCC1.CTRLA = TC_CLKSEL_DIV1024_gc; //Turn tcc1 back on
		}
		else
		{
			usartInput = usart_d0_in_char();
			charReceived = 0;
			switch (usartInput)
			{
				case 'w':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1046.50*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case '3':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1108.73*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 'e':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1174.66*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case '4':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1244.51*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 'r':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1318.51*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 't':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1396.91*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case '6':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1479.98*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 'y':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1567.98*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case '7':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1661.22*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 'u':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1760.00*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case '8':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1864.66*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 'i':
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(1975.53*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 'o': //Including for purposes of scale completion
					TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
					DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
					TCC0.PER = (int)(32000000/(2093.00*256)); //(32000000/(1760*256*PRESCALER)) = PER = 71
					TCC0.CNT = 0;
					TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
					break;
				case 's':
					//Toggle the waveform
					waveform = ~waveform;
					swap = 1;
					break;
				default:
					break;
			}
			TCC1.CNT = 0;
		}
		if(swap == 1)
		{
			TCC1.CTRLA = TC_CLKSEL_OFF_gc; //Turn tcc1 off
			DACA.CTRLA = DAC_CH1EN_bm|DAC_ENABLE_bm;
			TCE0.CTRLA = TC_CLKSEL_DIV1024_gc; //Prescaler of 1
			if(waveform == 0x37)
			{
				//Output a sine wave if waveform is true
				while ((DMA.CH0.CTRLB & DMA_CH_CHBUSY_bm) == DMA_CH_CHBUSY_bm)
				{
					if (TCE0.CNT == TCE0.PER)
					{
						TCE0.CTRLA = TC_CLKSEL_OFF_gc; //Prescaler of 1
						break;
					}
				}
				DMA.CH0.SRCADDR0 = (uint8_t)(&sine[1]);
				DMA.CH0.SRCADDR1 = (uint8_t)((uint16_t)(&sine[1])>>8);
				DMA.CH0.SRCADDR2 = (uint8_t)((uint32_t)(&sine[1])>>16);
				swap = 0;
			}
			else
			{
				//Output the sawtooth wave if waveform is false
				while ((DMA.CH0.CTRLB & DMA_CH_CHBUSY_bm) == DMA_CH_CHBUSY_bm)
				{
					if (TCE0.CNT == TCE0.PER)
					{
						TCE0.CTRLA = TC_CLKSEL_OFF_gc; //Prescaler of 1
						break;
					}
				}
				DMA.CH0.SRCADDR0 = (uint8_t)(&sawtooth[1]);
				DMA.CH0.SRCADDR1 = (uint8_t)((uint16_t)(&sawtooth[1])>>8);
				DMA.CH0.SRCADDR2 = (uint8_t)((uint32_t)(&sawtooth[1])>>16);
				swap = 0;
			}
		TCC0.CTRLA = TC_CLKSEL_OFF_gc;
		}
	}
}

void tcc0_init(void)
{
	TCC0.PER = 71; //(32000000/(1760*256*PRESCALER)) = PER = 71
	TCC0.CNT = 0;
	EVSYS.CH0MUX = EVSYS_CHMUX_TCC0_OVF_gc; //Trigger an event when overflowing
	TCC0.CTRLA = TC_CLKSEL_DIV1_gc; //Prescaler of 1
}

void tce0_init(void)
{
	TCE0.PER = 5000; //(32000000/(1760*256*PRESCALER)) = PER = 71
	TCE0.CNT = 0;
	TCE0.CTRLA = TC_CLKSEL_OFF_gc; //Prescaler of 1
}

void tcc1_init(void)
{
	TCC1.PER = 2000; //Every quarter second
	TCC1.CNT = 0;
	TCC1.INTCTRLA = TC_OVFINTLVL_LO_gc; //Interrupt every quarter second
	TCC1.CTRLA = TC_CLKSEL_DIV1024_gc; //Prescaler of 1
}

void DMA_init(void)
{
	DMA.CTRL = DMA_RESET_bm; //Reset the DMA module
	//Reload source after each block, increment after each byte, reload destination after every burst, increment after each byte
	DMA.CH0.ADDRCTRL = DMA_CH_SRCRELOAD_BLOCK_gc|DMA_CH_SRCDIR_INC_gc|DMA_CH_DESTRELOAD_BURST_gc|DMA_CH_DESTDIR_INC_gc; //Burst for source
	//Use DAC CH1 as trigger source
	DMA.CH0.TRIGSRC = DMA_CH_TRIGSRC_DACA_CH1_gc;
	//2 bytes * 256 entries = 512 bytes
	DMA.CH0.TRFCNT = 512;
	//Unlimited repeat
	DMA.CH0.REPCNT = 0;
	//Load the address of the beginning of the lookup table as the source
	DMA.CH0.SRCADDR0 = (uint8_t)(&sine[1]);
	DMA.CH0.SRCADDR1 = (uint8_t)((uint16_t)(&sine[1])>>8);
	DMA.CH0.SRCADDR2 = (uint8_t)((uint32_t)(&sine[1])>>16);
	//Load the address of the DACA.CH1 input register as the destination
	DMA.CH0.DESTADDR0 = (uint8_t)(&DACA.CH1DATA);
	DMA.CH0.DESTADDR1 = (uint8_t)((uint16_t)(&DACA.CH1DATA)>>8);
	DMA.CH0.DESTADDR2 = (uint8_t)((uint32_t)(&DACA.CH1DATA)>>16);
	//Enable DMA CH0, with unlimited repeat, single-shot transmission for burst transfers, two-byte data, and request a transfer on the data channel to begin
	DMA.CH0.CTRLA = DMA_CH_REPEAT_bm|DMA_CH_SINGLE_bm|DMA_CH_BURSTLEN_2BYTE_gc;
	DMA.CH0.CTRLA |= DMA_CH_ENABLE_bm|DMA_CH_TRFREQ_bm;
	//Enable DMA system
	DMA.CTRL |= DMA_ENABLE_bm;
}

ISR(USARTD0_RXC_vect)
{
	USARTD0.STATUS = USART_RXCIF_bm; //Clear the receive flag
	charReceived = 1; //Set global variable
}

ISR(TCC1_OVF_vect)
{
	//When interrupt occurs, turn off the DAC
	DACA.CTRLA = 0;
}