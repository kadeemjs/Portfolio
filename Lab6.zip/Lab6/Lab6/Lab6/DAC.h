/*
 * DAC.h
 *
 * Created: 7/21/2018 1:53:43 AM
 *  Author: Kadeem
 */ 

#include <avr/io.h>

void DAC_init(void);

void DAC_init(void)
{
	PORTA.DIR = PIN3_bm; //Set Pin3 (the DACA CH1 pin) as an output
	//Right-adjusted
	DACA.CTRLB = DAC_CHSEL_SINGLE1_gc|DAC_CH1TRIG_bm; // Channel 1, trigger on event
	//AREFB as the reference source
	DACA.CTRLC = DAC_REFSEL_AREFB_gc;
	//Trigger on event channel 0
	DACA.EVCTRL = DAC_EVSEL_0_gc;
	//Enable CH1
	DACA.CTRLA = DAC_CH1EN_bm;
}