/*
 * lab6_quiz.c
 *
 * Created: 7/30/2018 9:37:30 AM
 *  Author: Kadeem
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "DAC.h"
#include "USART.h"

extern void clock_init(void);
void tcc0_init(void);
void DMA_init(void);
void adc_init(void);

int volatile charReceived = 0;
int volatile ADCReceived = 0;
uint16_t volatile ADCOutput = 0;

int main(void)
{
	char volatile oldusartInput = 0;
	char volatile usartInput = 0;
	clock_init();
	DAC_init();
	usart_d0_init();
	tcc0_init();
	adc_init();
	ADCA.CH0.CTRL |= ADC_CH_START_bm;
	DACA.CTRLA |= DAC_ENABLE_bm;
	while (1)
	{
		if (charReceived == 1)
		{
			oldusartInput = usartInput;
			usartInput = usart_d0_in_char();
			if ((usartInput != '1')&&(usartInput != '2'))
			{
				usartInput = oldusartInput; // Account for keys other than 1 and 2 pressed
			}
			charReceived = 0;
		}
		if (ADCReceived == 1) {
			switch (usartInput)
			{
			case '1':
				if (ADCOutput > 3276)
				{
					ADCOutput = 3276;
				} else if (ADCOutput < 819)
				{
					ADCOutput = 819;
				} else 
				{
				}
				DACA.CH1DATA = ADCOutput; //Send the data to the DAC whenever it is received
				break;
			case '2':
				DACA.CH1DATA = ADCOutput; //Send the data to the DAC whenever it is received
				break;
			}
		}
	}
}

void tcc0_init(void)
{
	TCC0.PER = ((32000000/2)/44100); //Trigger event every 44.1 kHz
	TCC0.CNT = 0;
	EVSYS.CH0MUX = EVSYS_CHMUX_TCC0_OVF_gc; //Trigger an event when overflowing
	TCC0.CTRLA = TC_CLKSEL_DIV2_gc; //Prescaler of 1
}

void adc_init(void)
{
	//CDS+ and CDS- to be used as inputs
	PORTA.DIR = 0x00;
	ADCA.PRESCALER = ADC_PRESCALER_DIV16_gc; //2 MHz clock max for ADC
	ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc; //12 bit unsigned, right adjusted
	ADCA.REFCTRL = ADC_REFSEL_AREFB_gc; //AREFB as the reference voltage
	ADCA.CH0.CTRL = ADC_CH_INPUTMODE_SINGLEENDED_gc; //Single ended conversion mode
	ADCA.CH0.INTCTRL = ADC_CH_INTLVL0_bm; //Enable low level ADC channel interrupt
	ADCA.EVCTRL = ADC_SWEEP_0_gc|ADC_EVSEL_0123_gc|ADC_EVACT_CH0_gc; //Let event channel 0 trigger a conversion on ADCA channel 0
	PMIC.CTRL |= PMIC_LOLVLEN_bm; //Enable low-level interrupts
	ADCA.CTRLA = ADC_ENABLE_bm; //Enable the ADCA module
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN4_gc; //Pin4 for Wavegen, Internal ground for other end
	sei(); //Enable global interrupts
}

ISR(USARTD0_RXC_vect)
{
	USARTD0.STATUS = USART_RXCIF_bm; //Clear the receive flag
	charReceived = 1; //Set global variable
}

ISR(ADCA_CH0_vect)
{
	ADCA.CH0.INTFLAGS = ADC_CH_INTLVL0_bm; //Clear the interrupt flag
	ADCOutput = ((ADCA.CH0.RESL)|(ADCA.CH0.RESH << 8)); //Store the value of the output
	ADCReceived = 1;
}