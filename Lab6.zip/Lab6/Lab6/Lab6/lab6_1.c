/*
 * Lab6_1.c
 *
 * Created: 7/20/2018 9:39:14 PM
 * Author : Kadeem
 * The purpose of this program is to generate a 1V waveform using the DAC module
 */ 

#include <avr/io.h>
#include "DAC.h"

extern void clock_init(void);

int main(void)
{
    clock_init();
DAC_init();
	uint16_t volatile voltageData = ((uint16_t)((1/2.5)*(0xFFF)) & 0x0FFF);
	DACA.CTRLA |= DAC_ENABLE_bm;
    while (1) 
    {
		if((DACA.STATUS & PIN1_bm) == PIN1_bm)
		{
			DACA.CH1DATA = voltageData;	
		}
    }
}
