/*
 * lab5_5.c
 *
 * Created: 7/19/2018 12:27:53 PM
 *  Author: Kadeem
 * The purpose of this program is to read the data from either the CdS cell or the J3 jumper, and then output the data to the Data Visualizer
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "USART.h"

void adc_init(void);
void tcc0_init(void);
void DATA_STREAM(void);

uint16_t volatile ADCOutput0 = 0;
uint16_t volatile ADCOutput1 = 0;
uint16_t volatile ADCData = 0;
float volatile newADCOutput0 = 0;
float volatile newADCOutput1 = 0;
float volatile scale = 0;
int volatile ADC0Received = 0;
int volatile charReceived = 0;


int main(void)
{
	tcc0_init();
	usart_d0_init();
	adc_init();
	char volatile usartInput = 0;
	ADCA.CH0.CTRL |= ADC_CH_START_bm;
	ADCA.CH1.CTRL |= ADC_CH_START_bm;
	while (1)
	{
		if(ADC0Received == 1)
		{
			ADC0Received = 0;
			DATA_STREAM();
		}
	}
}

void adc_init(void)
{
	//CDS+ and CDS- to be used as inputs
	PORTA.DIR = 0x00;
	ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc|ADC_CONMODE_bm; //12 bit signed, right adjusted
	ADCA.REFCTRL = ADC_REFSEL_AREFB_gc; //AREFB as the reference voltage
	ADCA.CH0.CTRL = ADC_CH_INPUTMODE_DIFFWGAIN_gc; //Differential with gain conversion mode
	ADCA.CH1.CTRL = ADC_CH_INPUTMODE_DIFFWGAIN_gc; //Differential with gain conversion mode
	ADCA.CH1.INTCTRL = ADC_CH_INTLVL1_bm; //Enable medium level ADC channel interrupt
	ADCA.CH0.INTCTRL = ADC_CH_INTLVL0_bm; //Enable low level ADC channel interrupt
	ADCA.EVCTRL = ADC_SWEEP_01_gc|ADC_EVSEL_0123_gc|ADC_EVACT_SWEEP_gc; //Let event channel 0 trigger a conversion on ADCA channels 0 and 1
	PMIC.CTRL |= PMIC_LOLVLEN_bm||PMIC_MEDLVLEN_bm; //Enable low and medium-level interrupts
	ADCA.CTRLA = ADC_ENABLE_bm; //Enable the ADCA module
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN1_gc|ADC_CH_MUXNEG_PIN6_gc; //Pin1 for CS+, Pin6 for CS-
	ADCA.CH1.MUXCTRL = ADC_CH_MUXPOS_PIN4_gc|ADC_CH_MUXNEG_PIN5_gc; //Pin4 for IN0+, Pin5 for IN0-
	sei(); //Enable global interrupts
}

void tcc0_init(void)
{
	TCC0.PER = (2000000/256/200);
	TCC0.CNT = 0;
	EVSYS.CH0MUX = EVSYS_CHMUX_TCC0_OVF_gc;
	TCC0.CTRLA = TC_CLKSEL_DIV256_gc;
}

void DATA_STREAM(void)
{
	uint8_t volatile InByte = 0;
	uint8_t volatile StartByte = 0x31;
	uint8_t volatile StopByte = ~StartByte;
	usart_d0_out_char(StartByte);
	InByte = (uint8_t)(ADCData);
	usart_d0_out_char(InByte);
	InByte = (uint8_t)(ADCData>>8);
	usart_d0_out_char(InByte);
	usart_d0_out_char(StopByte);
}

ISR(ADCA_CH0_vect)
{
	ADCOutput0 = ((ADCA.CH0.RESL)|(ADCA.CH0.RESH << 8)); //Store the value of the output
	ADCOutput1 = ((ADCA.CH1.RESL)|(ADCA.CH1.RESH << 8)); //Store the value of the output
	newADCOutput0 = abs(ADCOutput0); //Take the absolute value to scale CdS between 0 and max value
	scale = (float)newADCOutput0/(0x7FF);
	newADCOutput1 = ADCOutput1*scale;
	ADCData = (uint16_t)newADCOutput1;
	ADC0Received = 1;
}
