/*
 * USART.h
 *
 * Created: 7/10/2018 7:21:01 PM
 *  Author: Kadeem
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

#define BSCALE -6
#define BSEL 5


void usart_d0_init(void);
void usart_d0_out_char(char d);
char usart_d0_in_char(void);

void usart_d0_init(void)
{
	PORTD.DIRCLR = PIN2_bm; //Set the TX line as an input
	PORTD.DIRSET = PIN3_bm; //Set the RX line as an output
	PORTD.OUT = PIN2_bm|PIN3_bm; //Set the pins to be high
	USARTD0.CTRLA = USART_RXCINTLVL0_bm; //Enable receive complete interrupt, low level
	PMIC.CTRL |= PORT_INT0LVL_LO_gc; //Enable low-level interrupts
	USARTD0.CTRLC = USART_CMODE_ASYNCHRONOUS_gc|USART_PMODE_DISABLED_gc|USART_CHSIZE_8BIT_gc; //Asynchronous, no parity, 8 bits
	USARTD0.BAUDCTRLA = (uint8_t)BSEL;
	USARTD0.BAUDCTRLB = (uint8_t)( (BSCALE << 4)|(BSEL>>8) );
	USARTD0.CTRLB = USART_TXEN_bm|USART_RXEN_bm; //Enable the transmitter and the receiver
}

void usart_d0_out_char(char d)
{
	while ((USARTD0.STATUS & PIN5_bm) != PIN5_bm)
	{
	}
	USARTD0.DATA = d;
}

char usart_d0_in_char(void)
{
	while ((USARTD0.STATUS & PIN7_bm) != PIN7_bm)
	{
	}
	return USARTD0.DATA;
}