/*
 * Lab5.c
 *
 * Created: 7/17/2018 10:30:22 AM
 * Author : Kadeem
 * The purpose of this program is to 
 */ 

#include <avr/io.h>

void adc_init(void);
int main(void)
{
	adc_init();
	int16_t volatile ADCOutput = 0;
	ADCA.CH0.CTRL |= ADC_CH_START_bm;
    while (1) 
    {
		while ((ADCA.CH0.INTFLAGS & PIN0_bm) != PIN0_bm)
		{
			//Loop that waits for conversion to be finished
		}
		ADCOutput = ((ADCA.CH0.RESL)|(ADCA.CH0.RESH << 8));
    }
}

void adc_init(void)
{
	//CDS+ and CDS- to be used as inputs
	PORTA.DIR = 0x00;
	ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc|ADC_CONMODE_bm; //12 bit signed, right adjusted
	ADCA.REFCTRL = ADC_REFSEL_AREFB_gc; //AREFB as the reference voltage
	ADCA.CH0.CTRL = ADC_CH_INPUTMODE_DIFFWGAIN_gc; //Differential with gain conversion mode
	ADCA.CTRLA = ADC_ENABLE_bm; //Enable the ADCA module
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN1_gc|ADC_CH_MUXNEG_PIN6_gc; //Pin1 for CS+, Pin6 for CS-
}