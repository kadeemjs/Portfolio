/*
 * lab5_5.c
 *
 * Created: 7/19/2018 12:27:53 PM
 *  Author: Kadeem
 * The purpose of this program is to read the data from either the CdS cell or the J3 jumper, and then output the data to the Data Visualizer
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "USART.h"

#define Top 39

void adc_init(void);
void tcc0_init(void);
void DATA_STREAM(void);

int16_t volatile ADCOutput = 0;
int volatile ADCReceived = 0;
int volatile charReceived = 0;


int main(void)
{
	tcc0_init();
	usart_d0_init();
	adc_init();
	char volatile usartInput = 0;
	ADCA.CH0.CTRL |= ADC_CH_START_bm;
	while (1)
	{
		if(ADCReceived == 1)
		{
			ADCReceived = 0;
			DATA_STREAM();
		}
		if (charReceived == 1)
		{
			usartInput = usart_d0_in_char();
			if (usartInput == '1')
			{
				ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN1_gc|ADC_CH_MUXNEG_PIN6_gc; //Pin1 for CS+, Pin6 for CS-
			}
			else if (usartInput == '2')
			{
				ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN4_gc|ADC_CH_MUXNEG_PIN5_gc; //Pin4 for IN0+, Pin5 for IN0-
			}
			else
			{
				
			}
			charReceived = 0;
		}
		else
		{
		}
	}
}

void adc_init(void)
{
	//CDS+ and CDS- to be used as inputs
	PORTA.DIR = 0x00;
	ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc|ADC_CONMODE_bm; //12 bit signed, right adjusted
	ADCA.REFCTRL = ADC_REFSEL_AREFB_gc; //AREFB as the reference voltage
	ADCA.CH0.CTRL = ADC_CH_INPUTMODE_DIFFWGAIN_gc; //Differential with gain conversion mode
	ADCA.CH0.INTCTRL = ADC_CH_INTLVL0_bm; //Enable low level ADC channel interrupt
	ADCA.EVCTRL = ADC_SWEEP_0_gc|ADC_EVSEL_0123_gc|ADC_EVACT_CH0_gc; //Let event channel 0 trigger a conversion on ADCA channel 0
	PMIC.CTRL |= PMIC_LOLVLEN_bm; //Enable low-level interrupts
	ADCA.CTRLA = ADC_ENABLE_bm; //Enable the ADCA module
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN1_gc|ADC_CH_MUXNEG_PIN6_gc; //Pin1 for CS+, Pin6 for CS-
	sei(); //Enable global interrupts
}

void tcc0_init(void)
{
	TCC0.PER = Top;
	TCC0.CNT = 0;
	EVSYS.CH0MUX = EVSYS_CHMUX_TCC0_OVF_gc;
	TCC0.CTRLA = TC_CLKSEL_DIV256_gc;
}

void DATA_STREAM(void)
{
	uint8_t volatile InByte = 0;
	uint8_t volatile StartByte = 0x31;
	uint8_t volatile StopByte = ~StartByte;
	usart_d0_out_char(StartByte);
	InByte = (uint8_t)(ADCOutput);
	usart_d0_out_char(InByte);
	InByte = (uint8_t)(ADCOutput>>8);
	usart_d0_out_char(InByte);
	usart_d0_out_char(StopByte);
}

ISR(ADCA_CH0_vect)
{
	ADCA.CH0.INTFLAGS = ADC_CH_INTLVL0_bm; //Clear the interrupt flag
	ADCOutput = ((ADCA.CH0.RESL)|(ADCA.CH0.RESH << 8)); //Store the value of the output
	ADCReceived = 1;
}

ISR(USARTD0_RXC_vect)
{
	USARTD0.STATUS = USART_RXCIF_bm; //Clear the receive flag
	charReceived = 1;
}