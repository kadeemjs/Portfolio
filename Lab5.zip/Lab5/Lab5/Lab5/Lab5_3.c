/*
 * Lab5_3.c
 *
 * Created: 7/18/2018 4:50:38 PM
 *  Author: Kadeem
 * The purpose of this program is to sample the CdS cell once each second, and then output the value through Putty
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "USART.h"

#define Top 31250

void adc_init(void);
void tcc0_init(void);

int16_t volatile ADCOutput = 0;
int volatile ADCReceived = 0;


int main(void)
{
	tcc0_init();
	usart_d0_init();
	adc_init();
	char volatile sign, char1, char2, char3 = 0;
	int volatile value = 0;
	uint16_t volatile newValue = 0;
	int volatile int1, int2, int3, int4, int5, absValue = 0;
	double volatile voltage, voltage2, voltage3, voltage4, voltage5 = 0;
	ADCA.CH0.CTRL |= ADC_CH_START_bm;
	while (1)
	{
		if (ADCReceived == 1)
		{
			ADCReceived = 0; //Clear the flag
			if (ADCOutput >= 0) //Determine the sign
			{
				sign = '+';
			}
			else
			{
				sign = '-';
			}
			usart_d0_out_char(sign);
			//Generate the decimal value
			value = (int)ADCOutput;
			absValue = abs(value);
			voltage = absValue*2.5/2048;
			int1 = (int)voltage;
			voltage2 = 10*(voltage - int1);
			int2 = (int)voltage2;
			voltage3 = 10*(voltage2 - int2);
			int3 = (int)voltage3;
			voltage4 = 10*(voltage3 - int3);
			int4 = (int)voltage3;
			voltage5 = 10*(voltage4 - int4);
			int5 = (int)voltage4;
			int1 = int1 + 48;
			int2 = int2 + 48;
			int3 = int3 + 48;
			int4 = int4 + 48;
			int5 = int5 + 48;
			usart_d0_out_char(int1);
			usart_d0_out_char('.');
			usart_d0_out_char(int2);
			usart_d0_out_char(int3);
			usart_d0_out_char(int4);
			usart_d0_out_char(int5);
			usart_d0_out_char(' ');
			usart_d0_out_char('V');
			usart_d0_out_char(' ');
			//Determine the hex value
			usart_d0_out_char('(');
			usart_d0_out_char('0');
			usart_d0_out_char('x');
			newValue = value;
			int volatile n = newValue % 16;
			newValue = newValue/16;
			if (n < 10) {
				char3 = n + 48;
			}
			else
			{
				char3 = n + 65 - 10;
			}
			n = newValue % 16;
			newValue = newValue/16;
			if (n < 10) {
				char2 = n + 48;
			}
			else
			{
				char2 = n + 65 - 10;
			}
			n = newValue % 16;
			newValue = newValue/16;
			if (n < 10) {
				char1 = n + 48;
			}
			else
			{
				char1 = n + 65 - 10;
			}
			usart_d0_out_char(char1);
			usart_d0_out_char(char2);
			usart_d0_out_char(char3);
			usart_d0_out_char(')');
			usart_d0_out_char(13);
			usart_d0_out_char(10);
		}
	}
}

void adc_init(void)
{
	//CDS+ and CDS- to be used as inputs
	PORTA.DIR = 0x00;
	ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc|ADC_CONMODE_bm; //12 bit signed, right adjusted
	ADCA.REFCTRL = ADC_REFSEL_AREFB_gc; //AREFB as the reference voltage
	ADCA.CH0.CTRL = ADC_CH_INPUTMODE_DIFFWGAIN_gc; //Differential with gain conversion mode
	ADCA.CH0.INTCTRL = ADC_CH_INTLVL0_bm; //Enable low level ADC channel interrupt
	ADCA.EVCTRL = ADC_SWEEP_0_gc|ADC_EVSEL_0123_gc|ADC_EVACT_CH0_gc; //Let event channel 0 trigger a conversion on ADCA channel 0
	PMIC.CTRL = PMIC_LOLVLEN_bm; //Enable low-level interrupts
	ADCA.CTRLA = ADC_ENABLE_bm; //Enable the ADCA module
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN1_gc|ADC_CH_MUXNEG_PIN6_gc; //Pin1 for CS+, Pin6 for CS-
	sei(); //Enable global interrupts
}

void tcc0_init(void)
{
	TCC0.PER = Top;
	TCC0.CNT = 0;
	EVSYS.CH0MUX = EVSYS_CHMUX_TCC0_OVF_gc;
	TCC0.CTRLA = TC_CLKSEL_DIV64_gc;
}

ISR(ADCA_CH0_vect)
{
	ADCA.CH0.INTFLAGS = ADC_CH_INTLVL0_bm; //Clear the interrupt flag
	ADCOutput = ((ADCA.CH0.RESL)|(ADCA.CH0.RESH << 8)); //Store the value of the output
	ADCReceived = 1;
}