/*
 * lab5_2.c
 *
 * Created: 7/17/2018 6:51:21 PM
 *  Author: Kadeem
 * The purpose of this program is to sample the CdS cell once each second.
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

#define Top 31250

void adc_init(void);
void tcc0_init(void);

int16_t volatile ADCOutput = 0;

int main(void)
{
	tcc0_init();
	adc_init();
	PORTD.DIRSET = PIN4_bm; //Set the red LED pin to be an output pin
	PORTD.OUTSET = PIN4_bm; //Set the LED to be off by default
	ADCA.CH0.CTRL |= ADC_CH_START_bm;
	while (1)
	{
		char volatile outputL = (char)(ADCOutput&0x00FF);
		char volatile outputH = (char)((ADCOutput&0x0F00)>>8);
	}
}

void adc_init(void)
{
	//CDS+ and CDS- to be used as inputs
	PORTA.DIR = 0x00;
	ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc|ADC_CONMODE_bm; //12 bit signed, right adjusted
	ADCA.REFCTRL = ADC_REFSEL_AREFB_gc; //AREFB as the reference voltage
	ADCA.CH0.CTRL = ADC_CH_INPUTMODE_DIFFWGAIN_gc; //Differential with gain conversion mode
	ADCA.CH0.INTCTRL = ADC_CH_INTLVL0_bm; //Enable low level ADC channel interrupt
	ADCA.EVCTRL = ADC_SWEEP_0_gc|ADC_EVSEL_0123_gc|ADC_EVACT_CH0_gc; //Let event channel 0 trigger a conversion on ADCA channel 0
	PMIC.CTRL = PMIC_LOLVLEN_bm; //Enable low-level interrupts
	ADCA.CTRLA = ADC_ENABLE_bm; //Enable the ADCA module
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN1_gc|ADC_CH_MUXNEG_PIN6_gc; //Pin1 for CS+, Pin6 for CS-
	sei(); //Enable global interrupts
}

void tcc0_init(void)
{
	TCC0.PER = Top;
	TCC0.CNT = 0;
	EVSYS.CH0MUX = EVSYS_CHMUX_TCC0_OVF_gc;
	TCC0.CTRLA = TC_CLKSEL_DIV64_gc;
}

ISR(ADCA_CH0_vect)
{
	ADCA.CH0.INTFLAGS = ADC_CH_INTLVL0_bm; //Clear the interrupt flag
	ADCOutput = ((ADCA.CH0.RESL)|(ADCA.CH0.RESH << 8)); //Store the value of the output
	PORTD.OUTTGL = PIN4_bm; //Toggle the LED
}