/*
 * Exam2_L.c
 *
 * Created: 8/7/2018 9:37:44 AM
 *  Author: Kadeem
 */ 
 #include <avr/io.h>
 #include "Initializations.h"

void DATA_STREAM(void);
void EBI_init(void);

int volatile InterruptFlag = 0; //Set global variable
int16_t volatile Red = 0;
int16_t volatile absRed = 0;
int16_t volatile Green = 0;
int16_t volatile absGreen = 0;
int16_t volatile Blue = 0;
int16_t volatile absBlue = 0;
int volatile Toggle = 0;

int main(void)
{
	//Initialize EBI
	EBI_init();
	spi_init();
	usart_d0_init();
	tcc0_init();
	accel_init();
	PORTD.DIRSET = 0x70; //LED lights as outputs
	PORTD.OUTSET = 0x70; //Turn off lights
	uint8_t volatile mem_value = 0xFF;
	while (1)
	{
		if (InterruptFlag == 1)
		{
			//PORTC.INTCTRL = PORT_INT0LVL_OFF_gc; //Disable low-level interrupts
			InterruptFlag = 0;
			DATA_STREAM();
			//PORTC.INTCTRL = PORT_INT0LVL_LO_gc; //Enable low-level interrupts
	}
	absRed = abs(Red);
	absGreen = abs(Green);
	absBlue = abs(Blue);
	if (Toggle == 1) {
		Toggle = 0;
		//If absGreen > absRed and Green > 0
			//Toggle D7 pin
			if ((absGreen > absRed) && (Green > 0))
			{
				if(mem_value == 0x7F)
				{
					mem_value = 0xFF;
				} else if (mem_value = 0xFF) {
					mem_value = 0x7F;
				} else {
					mem_value = 0xFF;
				}
			}
		//If absGreen > absRed and Green < 0
			//Toggle D0 pin
			else if ((absGreen > absRed) && (Green < 0))
			{
				if(mem_value == 0xFE)
				{
					mem_value = 0xFF;
					} else if (mem_value = 0xFF) {
					mem_value = 0xFE;
					} else {
					mem_value = 0xFF;
				}
			}
		//Else
			//Toggle Pin3 and Pin4
			else 
			{
				if(mem_value == 0xEF)
				{
					mem_value = 0xFF;
					} else if (mem_value = 0xFF) {
					mem_value = 0xEF;
					} else {
					mem_value = 0xFF;
				}
			}
		}
	__far_mem_write(0x3744AB, mem_value);
// 		absRed = abs(Red);
// 		absGreen = abs(Green);
// 		absBlue = abs(Blue);
// 		if ((absRed > absBlue)&&(absRed > absGreen))
// 		{
// 			PORTD.OUTSET = PIN5_bm|PIN6_bm;
// 			PORTD.OUTCLR = PIN4_bm;
// 		}
// 		else if ((absGreen > absRed)&&(absGreen > absBlue))
// 		{
// 			PORTD.OUTSET = PIN4_bm|PIN6_bm;
// 			PORTD.OUTCLR = PIN5_bm;	
// 		}
// 		else if ((absBlue > absRed)&&(absBlue > absGreen))
// 		{
// 				PORTD.OUTSET = PIN5_bm|PIN4_bm;
// 				PORTD.OUTCLR = PIN6_bm;
// 		} else
// 		{
// 			PORTD.OUTSET = PIN4_bm|PIN5_bm|PIN6_bm;
// 		}
	}
}

void DATA_STREAM(void)
{
	int volatile InByte = 0;
	uint8_t volatile StartByte = 0x31;
	uint8_t volatile StopByte = ~StartByte;
	usart_d0_out_char(StartByte);
	InByte = accel_read(OUT_X_L_A);
	Red = InByte;
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_X_H_A);
	Red = ((InByte<<8)|Red);
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Y_L_A);
	Green = InByte;
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Y_H_A);
	Green = ((InByte<<8)|Green);
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Z_L_A);
	Blue = InByte;
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Z_H_A);
	Blue = ((InByte<<8)|Blue);
	usart_d0_out_char(InByte);
	usart_d0_out_char(StopByte);
}
ISR(PORTC_INT0_vect)
{
	PORTC.INTFLAGS = PIN0_bm;
	InterruptFlag = 1;
}

void EBI_init(void)
{
	//Enable RE, WE, CS0, CS1, and ALE1
	PORTH.DIR = PIN5_bm|PIN4_bm|PIN2_bm|PIN1_bm|PIN0_bm;
	//Set the active low pins to by high by default
	PORTH.OUT = PIN5_bm|PIN4_bm|PIN1_bm|PIN0_bm;
	//Enable the address line outputs
	PORTK.DIR = PIN7_bm|PIN6_bm|PIN5_bm|PIN4_bm|PIN3_bm|PIN2_bm|PIN1_bm|PIN0_bm;
	//PortJ is an input port by default
	//SRAM mode, using only ALE1, with three ports (H, J, and K) enabled
	EBI.CTRL = EBI_SRMODE_ALE1_gc|EBI_IFMODE_3PORT_gc;
	//Load the starting address of the I/O ports into BASEADDR for CS0
	EBI.CS1.BASEADDR = 0x3740;
	EBI.CS1.CTRLA = EBI_CS_MODE_SRAM_gc|EBI_CS_ASPACE_4KB_gc;
}

ISR(TCC0_OVF_vect)
{
	Toggle = 1;
}