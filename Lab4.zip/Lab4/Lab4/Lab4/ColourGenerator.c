/*
 * ColourGenerator.c
 *
 * Created: 8/11/2018 11:27:11 AM
 *  Author: Kadeem
 *
 * The purpose of this program is to have users input red, green, and blue values, and output the result on the LED
 */ 

#include <avr/io.h>
#include "Initializations.h" 

const char BootPrompt[] = "Welcome to the LED Custom Colour Designer! Each time the 1 key is pressed, you will be prompted to input RGB values, and the desired colour will be generated using the tri-colour LED.";

void TCD0_init(void);
int volatile InterruptFlag = 0; //Set global variable for ADC interrupt
int volatile CharReceived = 0;
uint16_t Period = 0x1000;
int16_t volatile Red = 0;
float volatile absRed = 0;
int16_t volatile Green = 0;
float volatile absGreen = 0;
int16_t volatile Blue = 0;
float volatile absBlue = 0;
float volatile CCA = 0;
float volatile CCB = 0;
float volatile CCC = 0;
char volatile UsartOutput = 0;

char input[3] = "XXX";

char colourInputRed[3] = ""; //Value between 0 and 255
int volatile colourOutputRed = 0;
char colourInputGreen[3] = ""; //Value between 0 and 255
int volatile colourOutputGreen = 0;
char colourInputBlue[3] = ""; //Value between 0 and 255
int volatile colourOutputBlue = 0;

int main(void)
{
	usart_d0_init();
	TCD0_init();
	usart_d0_out_string(BootPrompt);
	usart_d0_out_string("Please press the '1' key to begin creating your custom colour.");
	sei();
	while (1)
	{
		if(CharReceived == 1)
		{
			CharReceived = 0;
			//If 1 is input, then ask for RGB values
			if (UsartOutput == '1')
			{
				//Turn off receive complete interrupt, function through polling only
				USARTD0.CTRLA = 0;
				usart_d0_out_string("Please enter three values between 0 and 255.");
				//CLear variable for later usage
				UsartOutput = 0;
				//For red:
				usart_d0_out_string("Red: ");
				//Take in a numerical input, if the input is enter, or if the input has three digits, then move on to the next one
				int volatile counter = 0;
				while (1)
				{
					//Take in an input, ensure that it is a number
					while ((UsartOutput < 48) || (UsartOutput > 57))
					{
						UsartOutput = usart_d0_in_char();
						if (UsartOutput == 13)
						{
							break;
						}
					}
					if (UsartOutput == 13)
					{
						break;
					}
					usart_d0_out_char(UsartOutput);
					//Add the input to temporary string at index counter if it isn't 13
					if (UsartOutput != 13)
					{
						input[counter] = UsartOutput;
					}
					if (counter == 2)
					{
						break;
					}
					//Clear UsartOutput
					UsartOutput = 0;
					//Decrement counter
					++counter;
				}
				usart_d0_out_char(13);
				usart_d0_out_char(10);
				usart_d0_out_char(13);
				usart_d0_out_char(10);
				//Count number of X's left in temporary variable, and shift the values by the number of X's
				int volatile Xcounter = 0;
				for(int volatile i = 0; i < 3; ++i)
				{
					if (input[i] == 'X')
					{
						++Xcounter;
					}
				}
				//Three cases, 0X, 1X, or 2X
				switch (Xcounter)
				{
				case 0:
					//No X's, so no shift
					strcpy(colourInputRed, input);
					//colourInputRed = input;
					break;
				case 1:
					//1 X, so shift right by 1
					colourInputRed[0] = '0';
					colourInputRed[1] = input[0];
					colourInputRed[2] = input[1];
					break;
				case 2:
					//2 X's, so shift right by 2
					colourInputRed[0] = '0';
					colourInputRed[1] = '0';
					colourInputRed[2] = input[0];
					break;
				default:
					strcpy(colourInputRed, "000");
					break;
				}
				//Reset variables
				counter = 0;
				strcpy(input, "XXX");
				Xcounter = 0;
				//CLear variable for later usage
				UsartOutput = 0;
				//For green:
				usart_d0_out_string("Green: ");
				//Take in a numerical input, if the input is enter, or if the input has three digits, then move on to the next one
				while (1)
				{
					//Take in an input, ensure that it is a number
					while ((UsartOutput < 48) || (UsartOutput > 57))
					{
						UsartOutput = usart_d0_in_char();
						if (UsartOutput == 13)
						{
							break;
						}
					}
					if (UsartOutput == 13)
					{
						break;
					}
					usart_d0_out_char(UsartOutput);
					//Add the input to temporary string at index counter if it isn't 13
					if (UsartOutput != 13)
					{
						input[counter] = UsartOutput;
					}
				if (counter == 2)
				{
					break;
				}
				//Clear UsartOutput
				UsartOutput = 0;
					//Decrement counter
					++counter;
				}
				usart_d0_out_char(13);
				usart_d0_out_char(10);
				usart_d0_out_char(13);
				usart_d0_out_char(10);
				//Count number of X's left in temporary variable, and shift the values by the number of X's
				for(int volatile i = 0; i < 3; ++i)
				{
					if (input[i] == 'X')
					{
						++Xcounter;
					}
				}
				//Three cases, 0X, 1X, or 2X
				switch (Xcounter)
				{
					case 0:
						//No X's, so n0 shift
						strcpy(colourInputGreen, input);
						break;
					case 1:
						//1 X, so shift right by 1
						colourInputGreen[0] = '0';
						colourInputGreen[1] = input[0];
						colourInputGreen[2] = input[1];
						break;
					case 2:
						//2 X's, so shift right by 2
						colourInputGreen[0] = '0';
						colourInputGreen[1] = '0';
						colourInputGreen[2] = input[0];
						break;
					default:
						strcpy(colourInputGreen, "000");
						break;
				}
				//Reset variables
				counter = 0;
				strcpy(input, "XXX");
				Xcounter = 0;
				//CLear variable for later usage
				UsartOutput = 0;
				//For blue:
				usart_d0_out_string("Blue: ");
				//Take in a numerical input, if the input is enter, or if the input has three digits, then move on to the next one
				while (1)
				{
					//Take in an input, ensure that it is a number
					while ((UsartOutput < 48) || (UsartOutput > 57))
					{
						UsartOutput = usart_d0_in_char();
						if (UsartOutput == 13)
						{
							break;
						}
					}
					if (UsartOutput == 13)
					{
						break;
					}
					usart_d0_out_char(UsartOutput);
					//Add the input to temporary string at index counter if it isn't 13
					if (UsartOutput != 13)
					{
						input[counter] = UsartOutput;
					}
				if (counter == 2)
				{
					break;
				}
				//Clear UsartOutput
				UsartOutput = 0;
					//Decrement counter
					++counter;
				}
				usart_d0_out_char(13);
				usart_d0_out_char(10);
				usart_d0_out_char(13);
				usart_d0_out_char(10);
				//Count number of X's left in temporary variable, and shift the values by the number of X's
				for(int volatile i = 0; i < 3; ++i)
				{
					if (input[i] == 'X')
					{
						++Xcounter;
					}
				}
				//Three cases, 0X, 1X, or 2X
				switch (Xcounter)
				{
					case 0:
						//No X's, so n0 shift
						strcpy(colourInputBlue, input);
						break;
					case 1:
						//1 X, so shift right by 1
						colourInputBlue[0] = '0';
						colourInputBlue[1] = input[0];
						colourInputBlue[2] = input[1];
						break;
					case 2:
						//2 X's, so shift right by 2
						colourInputBlue[0] = '0';
						colourInputBlue[1] = '0';
						colourInputBlue[2] = input[0];
						break;
					default:
						strcpy(colourInputBlue, "000");
						break;
				}
				//Reset variables
				counter = 0;
				strcpy(input, "XXX");
				Xcounter = 0;
				//Convert string values to integers
				colourOutputRed = atoi(colourInputRed);
				colourOutputGreen = atoi(colourInputGreen);
				colourOutputBlue = atoi(colourInputBlue);
				//Error check to ensure number is within range
				if (colourOutputRed > 256)
				{
					colourOutputRed = 256;
				}
				if (colourOutputGreen > 256)
				{
					colourOutputGreen = 256;
				}
				if (colourOutputBlue > 256)
				{
					colourOutputBlue = 256;
				}
				//Set compare register values to appropriate values
				CCA = (Period - ((4096/256)*colourOutputRed));
				CCB = (Period - ((4096/256)*colourOutputGreen));
				CCC = (Period - ((4096/256)*colourOutputBlue));
				//Set CC registers to control colours
				TCD0.CCA = ((uint16_t)CCA);
				TCD0.CCB = ((uint16_t)CCB);
				TCD0.CCC = ((uint16_t)CCC);
				usart_d0_out_string("The requested colour will now appear on the board!");
				usart_d0_out_string("Press 1 again to generate another colour.");
				//Re-enable the USART receive complete interrupt
				USARTD0.CTRLA = USART_RXCINTLVL0_bm; //Enable receive complete interrupt, low level
			}
		}
	}
}

void TCD0_init(void)
{
	PORTD.DIRSET = 0x70; //LED lights as outputs
	PORTD.OUTSET = 0x70; //Turn off lights
	PORTD.REMAP = PORT_TC0A_bm|PORT_TC0B_bm|PORT_TC0C_bm; //Remap so that the compare outputs are on pins 4-6
	TCD0.PER = 0xFFF; //Arbitrary, may change later
	TCD0.CNT = 0;
	TCD0.CTRLB = PIN4_bm|PIN5_bm|PIN6_bm|TC_WGMODE_SINGLESLOPE_gc; //Enable CCA, CCB, and CCC, using single-slope PWM mode
	//Use DMA to continually send output to PORT LED
	//Arbitrary, will change in the main
	TCD0.CCA = 0xFFFF;
	TCD0.CCB = 0xFFFF;
	TCD0.CCC = 0xFFFF;
	TCD0.CTRLA = TC_CLKSEL_DIV1_gc; //Enable the timer/counter
}

ISR(USARTD0_RXC_vect)
{
	USARTD0.STATUS = USART_RXCIF_bm; //Clear the interrupt flag
	UsartOutput = USARTD0.DATA;
	CharReceived = 1;
}