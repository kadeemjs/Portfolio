/*
*
*
* Created: 7/8/2018 4:07:57 PM
* Author : Kadeem
* The purpose of this program is to configure and enable the SPI master device.
* Important notes:
*	1. MSB first for the IMU
*	2. Maximum clock frequency for the clock is 10 MHz for the IMU
*	3. XMEGA is master device, IMU is slave device
*	4. Data from the IMU is driven at the falling edge and should be captured at the rising edge.
*	5. Leading clock edge is falling, trailing clock edge is rising.
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include "LSM330.h"
#define ACCEL_NOT_GYRO_gc 0x10 //Drive gyro enable pin high and accel enable pin low
#define Disable_IMU_gc 0x1C //Drive accel and gyro enable pins high
#define SPI_WRITE_gc (0x00 << 7) //Write to IMU
#define SPI_READ_gc (0x01 << 7) //Read from the IMU
#define CTRL_REG5_A_gc CTRL_REG5_A_ODR3|CTRL_REG5_A_ODR0|CTRL_REG5_A_ZEN|CTRL_REG5_A_YEN|CTRL_REG5_A_XEN 
#define CTRL_REG4_A_gc CTRL_REG4_A_DR_EN|CTRL_REG4_A_IEA|CTRL_REG4_A_INT1_EN //Data ready interrupt, 

void spi_init(void);
uint8_t spi_write(uint8_t data);
uint8_t spi_read(void);
void accel_write(uint8_t reg_addr, uint8_t data);
uint8_t accel_read(uint8_t reg_addr);
void accel_init(void);

void spi_init(void)
{
	//All but MISO are outputs, MISO on PIN6
	PORTF.DIR = PIN7_bm|PIN5_bm|PIN4_bm|PIN3_bm|PIN2_bm|PIN1_bm|PIN0_bm;
	PORTF.OUTSET = Disable_IMU_gc; //Disable accelerometer
	SPIF.CTRL = SPI_ENABLE_bm|SPI_MASTER_bm|SPI_MODE_3_gc;
	SPIF.INTCTRL = SPI_INTLVL_OFF_gc;
}

uint8_t spi_write(uint8_t data)
{
	SPIF.DATA = data;
	while((SPIF.STATUS & SPI_IF_bm) != SPI_IF_bm)
	{
		//Continuously polling the value
	}
	return SPIF.DATA;
}

uint8_t spi_read(void)
{
	return spi_write(0x37);
}

void accel_write(uint8_t reg_addr, uint8_t data)
{
	PORTF.OUTCLR = PIN3_bm; //Enable Accelerometer
	spi_write((reg_addr));
	spi_write(data);
	PORTF.OUTSET = PIN3_bm; //Disable Accelerometer
}

uint8_t accel_read(uint8_t reg_addr)
{
	PORTF.OUTCLR = PIN3_bm; //Enable Accelerometer
	uint8_t volatile register_value = 0;
	spi_write((reg_addr|PIN7_bm));
	register_value = spi_read();
	PORTF.OUTSET = PIN3_bm; //Disable Accelerometer
	return register_value;
}

void accel_init(void)
{
	PORTF.OUTCLR = PIN3_bm; //Enable Accelerometer
	PORTC.DIRCLR = 0xFF; //Let PORTC be an input port
	PORTC.INTCTRL = PORT_INT0LVL_LO_gc; //Enable low-level interrupts
	PMIC.CTRL = PORT_INT0LVL_LO_gc; //Enable low-level interrupts
	PORTC.INT0MASK = PIN7_bm; //Enable interrupt on pin 7
	PORTC.PIN7CTRL = PORT_ISC_RISING_gc; //Set falling edge trigger
	accel_write(CTRL_REG4_A, CTRL_REG4_A_STRT); //Soft reset
	accel_write(CTRL_REG4_A, CTRL_REG4_A_gc);
	accel_write(CTRL_REG5_A, CTRL_REG5_A_gc);//1600 Hz, enable X, Y, Z
	PORTF.OUTSET = PIN3_bm; //Disable Accelerometer
	sei(); //Now that interrupts are configured on the IMU, enable interrupts
}
