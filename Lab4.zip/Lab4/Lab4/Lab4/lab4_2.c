/*
 * lab4_2.c
 *
 * Created: 7/9/2018 9:53:54 AM
 *  Author: Kadeem
 * The purpose of this program is to initialize the SPI module, then continually transmit 0x53.
 */

#include <avr/io.h>
#include "SPI_Configuration.h"

int main (void)
{
	spi_init();
	uint8_t volatile SPIData = 0x53;
	uint8_t volatile SPInewData = 0;
	while (1)
	{
		SPInewData = spi_write(SPIData);
	}
}