/*
 * lab4_5.c
 *
 * Created: 7/10/2018 6:44:59 PM
 *  Author: Kadeem
 * The purpose of this program is to determine which of the axes experiences the largest acceleration, and show the relative values using PWM with the LEDs
 */
 #include <avr/io.h>
 #include "SPI_Configuration.h"
 #include "USART.h"

void DATA_STREAM(void);
int volatile InterruptFlag = 0; //Set global variable
int16_t volatile Red = 0;
int16_t volatile absRed = 0;
int16_t volatile Green = 0;
int16_t volatile absGreen = 0;
int16_t volatile Blue = 0;
int16_t volatile absBlue = 0;

int main(void)
{
	spi_init();
	usart_d0_init();
	accel_init();
	PORTD.DIRSET = 0x70; //LED lights as outputs
	PORTD.OUTSET = 0x70; //Turn off lights

	while (1)
	{
		if (InterruptFlag == 1)
		{
			//PORTC.INTCTRL = PORT_INT0LVL_OFF_gc; //Disable low-level interrupts
			InterruptFlag = 0;
			DATA_STREAM();
			//PORTC.INTCTRL = PORT_INT0LVL_LO_gc; //Enable low-level interrupts
		}
		absRed = abs(Red);
		absGreen = abs(Green);
		absBlue = abs(Blue);
		if ((absRed > absBlue)&&(absRed > absGreen))
		{
			PORTD.OUTSET = PIN5_bm|PIN6_bm;
			PORTD.OUTCLR = PIN4_bm;
		}
		else if ((absGreen > absRed)&&(absGreen > absBlue))
		{
			PORTD.OUTSET = PIN4_bm|PIN6_bm;
			PORTD.OUTCLR = PIN5_bm;	
		}
		else if ((absBlue > absRed)&&(absBlue > absGreen))
		{
				PORTD.OUTSET = PIN5_bm|PIN4_bm;
				PORTD.OUTCLR = PIN6_bm;
		} else
		{
			PORTD.OUTSET = PIN4_bm|PIN5_bm|PIN6_bm;
		}
	}
}

void DATA_STREAM(void)
{
	int volatile InByte = 0;
	uint8_t volatile StartByte = 0x31;
	uint8_t volatile StopByte = ~StartByte;
	usart_d0_out_char(StartByte);
	InByte = accel_read(OUT_X_L_A);
	Red = InByte;
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_X_H_A);
	Red = ((InByte<<8)|Red);
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Y_L_A);
	Green = InByte;
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Y_H_A);
	Green = ((InByte<<8)|Green);
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Z_L_A);
	Blue = InByte;
	usart_d0_out_char(InByte);
	InByte = accel_read(OUT_Z_H_A);
	Blue = ((InByte<<8)|Blue);
	usart_d0_out_char(InByte);
	usart_d0_out_char(StopByte);
}
ISR(PORTC_INT0_vect)
{
	PORTC.INTFLAGS = PIN0_bm;
	InterruptFlag = 1;
}