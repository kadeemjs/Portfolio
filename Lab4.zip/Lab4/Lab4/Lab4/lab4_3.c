/*
 * lab4_3.c
 *
 * Created: 7/9/2018 12:37:37 PM
 *  Author: Kadeem
 */
#include <avr/io.h>
#include "SPI_Configuration.h"
#include "LSM330.h"

int main(void)
{
	spi_init();
	uint8_t volatile value = accel_read(WHO_AM_I_A);
	while (1)
	{
	}
}