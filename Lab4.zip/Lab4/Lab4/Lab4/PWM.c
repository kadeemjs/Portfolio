/*
 * PWM.c
 *
 * Created: 8/7/2018 11:27:25 AM
 *  Author: Kadeem
 *
 * The purpose of this program is to use PWM to output the relative magnitudes of acceleration through the tri-colour LEDs
 * Use USART to control operation
 * If 1 is pressed, then operate in normal accelerometer reading and LED output mode
 * If 2 is pressed, then output LED colour based upon the following :
 * R for Red
 * B for Blue
 * G for Green
 * Y for Yellow
 * M for Magentaa
 * L for Black
 * W for White
 */ 

#include <avr/io.h>
#include "Initializations.h" 
//  #include "SPI_Configuration.h"
//  #include "USART.h"
 
 #define Period 0xFFF

const char AccelMode[] = "Welcome to the Accelerometer Mode! In this mode, the relative magnitudes of the accelerometer axis values will be shown through the usage of the tri-colour LED.";

const char Toggle[] = "To enter Accelerometer Mode, press 1. To enter Colour Generation Mode, press 2.";

const char ColourMode[] = "Welcome to the Colour Generation Mode! In this mode, particular colours can be generated, based upon the letter pressed on the keyboard.";

void DATA_STREAM(void);
void TCD0_init(void);
int volatile InterruptFlag = 0; //Set global variable for ADC interrupt
int volatile CharReceived = 0;
int16_t volatile Red = 0;
float volatile absRed = 0;
int16_t volatile Green = 0;
float volatile absGreen = 0;
int16_t volatile Blue = 0;
float volatile absBlue = 0;
float volatile CCA = 0;
float volatile CCB = 0;
float volatile CCC = 0;
char volatile UsartOutput = 0;

uint8_t volatile BlueLED = PIN4_bm|PIN5_bm;
uint8_t volatile RedLED = PIN5_bm|PIN6_bm;
uint8_t volatile GreenLED = PIN4_bm|PIN6_bm;
uint8_t volatile CyanLED = PIN4_bm;
uint8_t volatile MagentaLED = PIN5_bm;
uint8_t volatile YellowLED = PIN6_bm;
uint8_t volatile BlackLED = PIN4_bm|PIN5_bm|PIN6_bm;
uint8_t volatile WhiteLED = 0;

int volatile colourOutput = 0;

int main(void)
{
	spi_init();
	usart_d0_init();
	TCD0_init();
	accel_init();
	usart_d0_out_string(AccelMode);
	usart_d0_out_string(Toggle);
	int volatile Mode = 1;
	while (1)
	{
		if(CharReceived == 1)
		{
			colourOutput = 1;
			CharReceived = 0;
			switch (UsartOutput)
			{
			case '1':
				if (Mode == 2)
				{
					Mode = 1;
					PORTD.REMAP = PORT_TC0A_bm|PORT_TC0B_bm|PORT_TC0C_bm; //Remap so that the compare outputs are on pins 4-6
					usart_d0_out_string(AccelMode);
					usart_d0_out_string(Toggle);
					//Turn on the timer
					TCD0.CTRLA = TC_CLKSEL_DIV1_gc; //Enable the timer/counter
				}
				break;
			case '2':
				if (Mode == 1)
				{
					Mode = 2;
					PORTD.REMAP = 0;
					usart_d0_out_string(ColourMode);
					usart_d0_out_string(Toggle);
					//Turn off the timer
					TCD0.CTRLA = TC_CLKSEL_OFF_gc; //Disable the timer/counter
				}
				break;
			default:
				break;
			}
		}
		if (Mode == 1)
		{
			if (InterruptFlag == 1)
			{
				InterruptFlag = 0;
				DATA_STREAM();
				absRed = abs(Red);
				absGreen = abs(Green);
				absBlue = abs(Blue);
				//For PWM, the output is high when CNT is below CCx, and low when CNT is above CCx
				CCA = (Period - (Period*absRed/0x7FFF));
				CCB = (Period - (Period*absGreen/0x7FFF));
				CCC = (Period - (Period*absBlue/0x7FFF));
				TCD0.CCA = (uint16_t)CCA;
				TCD0.CCB = (uint16_t)CCB;
				TCD0.CCC = (uint16_t)CCC;
			}
		}
		if (Mode == 2)
		{
			switch (UsartOutput)
			{
			case 'w':
				PORTD.OUT = WhiteLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("White");
					colourOutput = 0;
				}
				break;
			case 'b':
				PORTD.OUT = BlueLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("Blue");
					colourOutput = 0;
				}
				break;
			case 'r':
				PORTD.OUT = RedLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("Red");
					colourOutput = 0;
				}
				break;
			case 'g':
				PORTD.OUT = GreenLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("Green");
					colourOutput = 0;
				}
				break;
			case 'y':
				PORTD.OUT = YellowLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("Yellow");
					colourOutput = 0;
				}
				break;
			case 'k':
				PORTD.OUT = BlackLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("Black");
					colourOutput = 0;
				}
				break;
			case 'm':
				PORTD.OUT = MagentaLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("Magenta");
					colourOutput = 0;
				}
				break;
			case 'c':
				PORTD.OUT = CyanLED;
				if (colourOutput == 1)
				{
					usart_d0_out_string("Cyan");
					colourOutput = 0;
				}
				break;
			default:
				PORTD.OUT = BlackLED;
				break;
			}
		}
	}
}

void DATA_STREAM(void)
{
	int volatile InByte = 0;
	InByte = accel_read(OUT_X_L_A);
	Red = InByte;
	InByte = accel_read(OUT_X_H_A);
	Red = ((InByte<<8)|Red);
	InByte = accel_read(OUT_Y_L_A);
	Green = InByte;
	InByte = accel_read(OUT_Y_H_A);
	Green = ((InByte<<8)|Green);
	InByte = accel_read(OUT_Z_L_A);
	Blue = InByte;
	InByte = accel_read(OUT_Z_H_A);
	Blue = ((InByte<<8)|Blue);
}

void TCD0_init(void)
{
	PORTD.DIRSET = 0x70; //LED lights as outputs
	PORTD.OUTSET = 0x70; //Turn off lights
	PORTD.REMAP = PORT_TC0A_bm|PORT_TC0B_bm|PORT_TC0C_bm; //Remap so that the compare outputs are on pins 4-6
	TCD0.PER = Period; //Arbitrary, may change later
	TCD0.CNT = 0;
	TCD0.CTRLB = PIN4_bm|PIN5_bm|PIN6_bm|TC_WGMODE_SINGLESLOPE_gc; //Enable CCA, CCB, and CCC, using single-slope PWM mode
	//Use DMA to continually send output to PORT LED
	//Arbitrary, will change in the main
	TCD0.CCA = Period;
	TCD0.CCB = Period;
	TCD0.CCC = Period;
	TCD0.CTRLA = TC_CLKSEL_DIV1_gc; //Enable the timer/counter
}

ISR(PORTC_INT0_vect)
{
	PORTC.INTFLAGS = PIN0_bm;
	InterruptFlag = 1;
}

ISR(USARTD0_RXC_vect)
{
	USARTD0.STATUS = USART_RXCIF_bm; //Clear the interrupt flag
	UsartOutput = USARTD0.DATA;
	CharReceived = 1;
}