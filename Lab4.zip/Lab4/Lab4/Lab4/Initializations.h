/*
 * Initializations.h
 *
 * Created: 8/6/2018 12:24:27 PM
 *  Author: Kadeem
 *
 * The purpose of this program is to contain any necessary initializations
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "LSM330.h"

#define ACCEL_NOT_GYRO_gc 0x10 //Drive gyro enable pin high and accel enable pin low
#define Disable_IMU_gc 0x1C //Drive accel and gyro enable pins high
#define SPI_WRITE_gc (0x00 << 7) //Write to IMU
#define SPI_READ_gc (0x01 << 7) //Read from the IMU
#define CTRL_REG5_A_gc CTRL_REG5_A_ODR3|CTRL_REG5_A_ODR0|CTRL_REG5_A_ZEN|CTRL_REG5_A_YEN|CTRL_REG5_A_XEN
#define CTRL_REG4_A_gc CTRL_REG4_A_DR_EN|CTRL_REG4_A_IEA|CTRL_REG4_A_INT1_EN //Data ready interrupt,
#define BSCALE -6
#define BSEL 5
#define Top 512
#ifndef EBI_DRIVER_H
#define EBI_DRIVER_H

#define __far_mem_read(addr)                    \
(__extension__({                    \
	uint32_t temp32 = (uint32_t)(addr); \
	uint8_t result;                     \
	asm volatile(                       \
	"in __tmp_reg__, %2"     "\n\t" \
	"out %2, %C1"            "\n\t" \
	"movw r30, %1"           "\n\t" \
	"ld %0, Z"               "\n\t" \
	"out %2, __tmp_reg__"    "\n\t" \
	: "=r" (result)                 \
	: "r" (temp32),                 \
	"I" (_SFR_IO_ADDR(RAMPZ))     \
	: "r30", "r31"                  \
	);                                  \
	result;                             \
}))

#define __far_mem_write(addr, data)             \
(__extension__({                    \
	uint32_t temp32 = (uint32_t)(addr); \
	asm volatile(                       \
	"in __tmp_reg__, %1"     "\n\t" \
	"out %1, %C0"            "\n\t" \
	"movw r30, %0"           "\n\t" \
	"st Z, %2"               "\n\t" \
	"out %1, __tmp_reg__"           \
	:                               \
	: "r" (temp32),                 \
	"I" (_SFR_IO_ADDR(RAMPZ)),    \
	"r" ((uint8_t)data)           \
	: "r30", "r31"                  \
	);                                  \
}))

#define _far_mem_enter_ISR()  uint8_t volatile saved_rampz = RAMPZ; \
RAMPZ = 0;
#define __far_mem_exit_ISR()   RAMPZ = saved_rampz;

#endif /* EBI_DRIVER_H_ */

void DAC_init(void);
void usart_d0_init(void);
void usart_d0_out_char(char d);
void usart_d0_out_string(const char s[]);
char usart_d0_in_char(void);
void spi_init(void);
uint8_t spi_write(uint8_t data);
uint8_t spi_read(void);
void accel_write(uint8_t reg_addr, uint8_t data);
uint8_t accel_read(uint8_t reg_addr);
void accel_init(void);
void adc_init(void);
void tcc0_init(void);
//void DMA_init(void);

void DAC_init(void)
{
	PORTA.DIR = PIN3_bm; //Set Pin3 (the DACA CH1 pin) as an output
	//Right-adjusted
	DACA.CTRLB = DAC_CHSEL_SINGLE1_gc|DAC_CH1TRIG_bm; // Channel 1, trigger on event
	//AREFB as the reference source
	DACA.CTRLC = DAC_REFSEL_AREFB_gc;
	//Trigger on event channel 0
	DACA.EVCTRL = DAC_EVSEL_0_gc;
	//Enable CH1
	DACA.CTRLA = DAC_CH1EN_bm;
}

void usart_d0_init(void)
{
	PORTD.DIRCLR = PIN2_bm; //Set the TX line as an input
	PORTD.DIRSET = PIN3_bm; //Set the RX line as an output
	PORTD.OUT = PIN2_bm|PIN3_bm; //Set the pins to be high
	USARTD0.CTRLA = USART_RXCINTLVL0_bm; //Enable receive complete interrupt, low level
	PMIC.CTRL = PORT_INT0LVL_LO_gc; //Enable low-level interrupts
	USARTD0.CTRLC = USART_CMODE_ASYNCHRONOUS_gc|USART_PMODE_DISABLED_gc|USART_CHSIZE_8BIT_gc; //Asynchronous, no parity, 8 bits
	USARTD0.BAUDCTRLA = (uint8_t)BSEL;
	USARTD0.BAUDCTRLB = (uint8_t)( (BSCALE << 4)|(BSEL>>8) );
	USARTD0.CTRLB = USART_TXEN_bm|USART_RXEN_bm; //Enable the transmitter and the receiver
}

void usart_d0_out_char(char d)
{
	while ((USARTD0.STATUS & PIN5_bm) != PIN5_bm)
	{
	}
	USARTD0.DATA = d;
}


void usart_d0_out_string(const char s[])
{
	for (int volatile i = 0; i < strlen(s); ++i)
	{
		char volatile d = s[i];
		usart_d0_out_char(d);
	}
		usart_d0_out_char(13);
		usart_d0_out_char(10);
		usart_d0_out_char(13);
		usart_d0_out_char(10);
}

char usart_d0_in_char(void)
{
	while ((USARTD0.STATUS & PIN7_bm) != PIN7_bm)
	{
	}
	return USARTD0.DATA;
}

void spi_init(void)
{
	//All but MISO are outputs, MISO on PIN6
	PORTF.DIR = PIN7_bm|PIN5_bm|PIN4_bm|PIN3_bm|PIN2_bm|PIN1_bm|PIN0_bm;
	PORTF.OUTSET = Disable_IMU_gc; //Disable accelerometer
	SPIF.CTRL = SPI_ENABLE_bm|SPI_MASTER_bm|SPI_MODE_3_gc;
	SPIF.INTCTRL = SPI_INTLVL_OFF_gc;
}

uint8_t spi_write(uint8_t data)
{
	SPIF.DATA = data;
	while((SPIF.STATUS & SPI_IF_bm) != SPI_IF_bm)
	{
		//Continuously polling the value
	}
	return SPIF.DATA;
}

uint8_t spi_read(void)
{
	return spi_write(0x37);
}

void accel_write(uint8_t reg_addr, uint8_t data)
{
	PORTF.OUTCLR = PIN3_bm; //Enable Accelerometer
	spi_write((reg_addr));
	spi_write(data);
	PORTF.OUTSET = PIN3_bm; //Disable Accelerometer
}

uint8_t accel_read(uint8_t reg_addr)
{
	PORTF.OUTCLR = PIN3_bm; //Enable Accelerometer
	uint8_t volatile register_value = 0;
	spi_write((reg_addr|PIN7_bm));
	register_value = spi_read();
	PORTF.OUTSET = PIN3_bm; //Disable Accelerometer
	return register_value;
}

void accel_init(void)
{
	PORTF.OUTCLR = PIN3_bm; //Enable Accelerometer
	PORTC.DIRCLR = 0xFF; //Let PORTC be an input port
	PORTC.INTCTRL = PORT_INT0LVL_LO_gc; //Enable low-level interrupts
	PMIC.CTRL = PORT_INT0LVL_LO_gc; //Enable low-level interrupts
	PORTC.INT0MASK = PIN7_bm; //Enable interrupt on pin 7
	PORTC.PIN7CTRL = PORT_ISC_RISING_gc; //Set falling edge trigger
	accel_write(CTRL_REG4_A, CTRL_REG4_A_STRT); //Soft reset
	accel_write(CTRL_REG4_A, CTRL_REG4_A_gc);
	accel_write(CTRL_REG5_A, CTRL_REG5_A_gc);//1600 Hz, enable X, Y, Z
	PORTF.OUTSET = PIN3_bm; //Disable Accelerometer
	sei(); //Now that interrupts are configured on the IMU, enable interrupts
}

void adc_init(void)
{
	//CDS+ and CDS- to be used as inputs
	PORTA.DIR = 0x00;
	ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc|ADC_CONMODE_bm; //12 bit signed, right adjusted
	ADCA.REFCTRL = ADC_REFSEL_AREFB_gc; //AREFB as the reference voltage
	ADCA.CH0.CTRL = ADC_CH_INPUTMODE_DIFFWGAIN_gc; //Differential with gain conversion mode
	ADCA.CH0.INTCTRL = ADC_CH_INTLVL0_bm; //Enable low level ADC channel interrupt
	ADCA.EVCTRL = ADC_SWEEP_0_gc|ADC_EVSEL_0123_gc|ADC_EVACT_CH0_gc; //Let event channel 0 trigger a conversion on ADCA channel 0
	PMIC.CTRL |= PMIC_LOLVLEN_bm; //Enable low-level interrupts
	ADCA.CTRLA = ADC_ENABLE_bm; //Enable the ADCA module
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN1_gc|ADC_CH_MUXNEG_PIN6_gc; //Pin1 for CS+, Pin6 for CS-
	sei(); //Enable global interrupts
}

void tcc0_init(void)
{
	TCC0.PER = (2000000)/(1024*4); //2 Hz toggle
	TCC0.CNT = 0;
	EVSYS.CH0MUX = EVSYS_CHMUX_TCC0_OVF_gc;
	TCC0.CTRLA = TC_CLKSEL_DIV1024_gc;
	//Interrupts
	TCC0.INTCTRLA = TC_OVFINTLVL_LO_gc;
	PMIC.CTRL |= PMIC_LOLVLEN_bm;
}

// void DMA_init(void)
// {
// 	DMA.CTRL = DMA_RESET_bm; //Reset the DMA module
// 	//Reload source after each block, increment after each byte, reload destination after every burst, increment after each byte
// 	DMA.CH0.ADDRCTRL = DMA_CH_SRCRELOAD_BLOCK_gc|DMA_CH_SRCDIR_INC_gc|DMA_CH_DESTRELOAD_BURST_gc|DMA_CH_DESTDIR_INC_gc; //Burst for source
// 	//Use DAC CH1 as trigger source
// 	DMA.CH0.TRIGSRC = DMA_CH_TRIGSRC_DACA_CH1_gc;
// 	//2 bytes * 256 entries = 512 bytes
// 	DMA.CH0.TRFCNT = 512;
// 	//Unlimited repeat
// 	DMA.CH0.REPCNT = 0;
// 	//Load the address of the beginning of the lookup table as the source
// 	DMA.CH0.SRCADDR0 = (uint8_t)(&sine[1]);
// 	DMA.CH0.SRCADDR1 = (uint8_t)((uint16_t)(&sine[1])>>8);
// 	DMA.CH0.SRCADDR2 = (uint8_t)((uint32_t)(&sine[1])>>16);
// 	//Load the address of the DACA.CH1 input register as the destination
// 	DMA.CH0.DESTADDR0 = (uint8_t)(&DACA.CH1DATA);
// 	DMA.CH0.DESTADDR1 = (uint8_t)((uint16_t)(&DACA.CH1DATA)>>8);
// 	DMA.CH0.DESTADDR2 = (uint8_t)((uint32_t)(&DACA.CH1DATA)>>16);
// 	//Enable DMA CH0, with unlimited repeat, single-shot transmission for burst transfers, two-byte data, and request a transfer on the data channel to begin
// 	DMA.CH0.CTRLA = DMA_CH_REPEAT_bm|DMA_CH_SINGLE_bm|DMA_CH_BURSTLEN_2BYTE_gc;
// 	DMA.CH0.CTRLA |= DMA_CH_ENABLE_bm|DMA_CH_TRFREQ_bm;
// 	//Enable DMA system
// 	DMA.CTRL |= DMA_ENABLE_bm;
/*}*/