/*
 * Lab4.c
 *
 * Created: 7/8/2018 4:07:57 PM
 * Author : Kadeem
 * The purpose of this program is to configure and enable the SPI master device.
 * Important notes:
 *	1. MSB first for the IMU
 *	2. Maximum clock frequency is 10 MHz
 *  3. XMEGA is master, IMU is slave
 *  4. Data from the IMU is driven at the falling edge and should be captured at the rising edge. 
 *	5. Leading clock edge is falling, trailing clock edge is rising.
 */ 

#include <avr/io.h>
#include "SPI_Configuration.h"
 
int main(void)
{
	void spi_init();
	uint8_t volatile data = 0x37;
    /* Replace with your application code */
    while (1) 
    {
		uint8_t volatile newData = spi_write(data);
    }
}

 