/*
 * Lab4Quiz.c
 *
 * Created: 7/16/2018 9:29:23 AM
 * Author : Kadeem
 */ 

#include <avr/io.h>
#include "SPI_Configuration.h"
#include "USART.h"

void DATA_STREAM(void);
int volatile InterruptFlag = 0; //Set global variable
char volatile char_received = 0;
int16_t volatile Red = 0; //X axis
int16_t volatile Green = 0; //Y axis
int16_t volatile Blue = 0; //Z axis

int main(void)
{
	spi_init();
	usart_d0_init();
	accel_init();
	PORTD.DIRSET = 0x70; //LED lights as outputs
	PORTD.OUTSET = 0x70; //Turn off lights

	while (1)
	{
		if (InterruptFlag == 1)
		{
			InterruptFlag = 0;
			DATA_STREAM();
		}
		Red = abs(Red);
		Green = abs(Green);
		Blue = abs(Blue);
		if (char_received == '1')
		{
			char_received = 0;
			if ((Red > Blue)&&(Red > Green))
			{
				usart_d0_out_char('X');
				usart_d0_out_char(13);
				usart_d0_out_char(10);
			}
			else if ((Green > Red)&&(Green > Blue))
			{
				usart_d0_out_char('Y');
				usart_d0_out_char(13);
				usart_d0_out_char(10);
			}
			else if ((Blue > Red)&&(Blue > Green))
			{
				usart_d0_out_char('Z');
				usart_d0_out_char(13);
				usart_d0_out_char(10);
			} 
			else
			{
			}
		}
	}
}

void DATA_STREAM(void)
{
	int volatile InByte = 0;
	InByte = accel_read(OUT_X_L_A);
	Red = InByte;
	InByte = accel_read(OUT_X_H_A);
	Red = ((InByte<<8)|Red);
	InByte = accel_read(OUT_Y_L_A);
	Green = InByte;
	InByte = accel_read(OUT_Y_H_A);
	Green = ((InByte<<8)|Green);
	InByte = accel_read(OUT_Z_L_A);
	Blue = InByte;
	InByte = accel_read(OUT_Z_H_A);
	Blue = ((InByte<<8)|Blue);
}

ISR(PORTC_INT0_vect)
{
	PORTC.INTFLAGS = PIN0_bm;
	InterruptFlag = 1;
}

ISR(USARTD0_RXC_vect)
{
	USARTD0.DATA = PIN7_bm; //Clear the interrupt flag
	char_received = usart_d0_in_char();
}