/*
 * Final Project.c
 *
 * Created: 11/24/2018 11:08:25 PM
 * Author : Kadeem
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

const uint16_t sinewave[] =
{
	0x200,0x20c,0x219,0x225,0x232,0x23e,0x24b,0x257,
	0x263,0x270,0x27c,0x288,0x294,0x2a0,0x2ac,0x2b8,
	0x2c3,0x2cf,0x2da,0x2e5,0x2f1,0x2fc,0x306,0x311,
	0x31c,0x326,0x330,0x33a,0x344,0x34e,0x357,0x360,
	0x369,0x372,0x37a,0x383,0x38b,0x393,0x39a,0x3a2,
	0x3a9,0x3b0,0x3b6,0x3bd,0x3c3,0x3c8,0x3ce,0x3d3,
	0x3d8,0x3dd,0x3e1,0x3e5,0x3e9,0x3ec,0x3f0,0x3f3,
	0x3f5,0x3f7,0x3f9,0x3fb,0x3fd,0x3fe,0x3fe,0x3ff,
	0x3ff,0x3ff,0x3fe,0x3fe,0x3fd,0x3fb,0x3f9,0x3f7,
	0x3f5,0x3f3,0x3f0,0x3ec,0x3e9,0x3e5,0x3e1,0x3dd,
	0x3d8,0x3d3,0x3ce,0x3c8,0x3c3,0x3bd,0x3b6,0x3b0,
	0x3a9,0x3a2,0x39a,0x393,0x38b,0x383,0x37a,0x372,
	0x369,0x360,0x357,0x34e,0x344,0x33a,0x330,0x326,
	0x31c,0x311,0x306,0x2fc,0x2f1,0x2e5,0x2da,0x2cf,
	0x2c3,0x2b8,0x2ac,0x2a0,0x294,0x288,0x27c,0x270,
	0x263,0x257,0x24b,0x23e,0x232,0x225,0x219,0x20c,
	0x200,0x1f3,0x1e6,0x1da,0x1cd,0x1c1,0x1b4,0x1a8,
	0x19c,0x18f,0x183,0x177,0x16b,0x15f,0x153,0x147,
	0x13c,0x130,0x125,0x11a,0x10e,0x103,0xf9,0xee,
	0xe3,0xd9,0xcf,0xc5,0xbb,0xb1,0xa8,0x9f,
	0x96,0x8d,0x85,0x7c,0x74,0x6c,0x65,0x5d,
	0x56,0x4f,0x49,0x42,0x3c,0x37,0x31,0x2c,
	0x27,0x22,0x1e,0x1a,0x16,0x13,0xf,0xc,
	0xa,0x8,0x6,0x4,0x2,0x1,0x1,0x0,
	0x0,0x0,0x1,0x1,0x2,0x4,0x6,0x8,
	0xa,0xc,0xf,0x13,0x16,0x1a,0x1e,0x22,
	0x27,0x2c,0x31,0x37,0x3c,0x42,0x49,0x4f,
	0x56,0x5d,0x65,0x6c,0x74,0x7c,0x85,0x8d,
	0x96,0x9f,0xa8,0xb1,0xbb,0xc5,0xcf,0xd9,
	0xe3,0xee,0xf9,0x103,0x10e,0x11a,0x125,0x130,
	0x13c,0x147,0x153,0x15f,0x16b,0x177,0x183,0x18f,
	0x19c,0x1a8,0x1b4,0x1c1,0x1cd,0x1da,0x1e6,0x1f3
}; 

void ADC_init(void);
uint16_t ADC0_read(void);
void TC0_init(void);
void TC1_init(uint8_t maxValue);
void TC2_init(void);
void spi_init(void);
void spi_write(uint16_t finalData);
void lcd_init(void);
void lcd_command(char);
void lcd_char(char);
void lcd_write(char s[]);
void out_string(char s[]);
void configure_buttons(void);
void welcome(void);
void select_pokemon(void);
void set_stats(void);
void foe_appears(void);
void battle_phase(void);
void int_to_string(unsigned long n);

int volatile counts = 0;
int volatile max_counts = 10;
int volatile in_battle_phase = 0;
uint8_t volatile i = 0;
int volatile left_or_right = 0; //Left is 1, right is 2
int volatile A = 0;
uint8_t volatile Pokemon_choice = 0;
double volatile user_attack = 0;
double volatile user_defense = 0;
double volatile user_hp = 0;
double volatile user_attack_reduction = 1;
double volatile user_effective_attack = 0;
double volatile foe_attack = 30;
double volatile foe_defense = 41;
double volatile foe_hp = 38;
double volatile foe_attack_reduction = 1;
double volatile foe_effective_attack = 0;
double volatile raw_damage = 40;
double volatile max_user_hp = 0;
int volatile foe_move = 0;
int volatile damage_to_deal = 0;

int main(void)
{
	//Initialize input and output on PORTC
	DDRC = 0xF8; //All output except C0:2
	//Disable on-chip JTAG to use PORTC
	MCUCR |=(1<<JTD);
	MCUCR |=(1<<JTD);
	//LEDs are all active low, pull-up resistors for input pins, white LED on
	PORTC = 0x7B; //Should be 0x3B, but soldering issue requires 0x7B
	//Initializations
	ADC_init();
	spi_init();
	lcd_init();
	_delay_ms(50);
	lcd_command(0x01); //Clear screen cursor home
	TC1_init(50);
	TC2_init();
	configure_buttons();
	welcome();
	select_pokemon();
	set_stats();
	foe_appears();
	in_battle_phase = 1;
	battle_phase();
    while (1) 
    {
    }
}

void ADC_init(void)
{
	DDRA = 0x80; //PA is all inputs
	DIDR0 = (1<<ADC0D); //Disable digital input buffer on PA0 to reduce power consumption
	ADMUX = (1<<REFS0)|(0x0); //AVcc pin as reference, right adjusted format, gain of 1, using ADC0
	ADCSRA |= (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); //Enable the ADC, and start the first conversion, prescaler of 128
}

//For frequency
uint16_t ADC0_read(void)
{
	ADMUX = (1<<REFS0)|(0x0); //Using ADC0
	ADCSRA |= (1<<ADSC);
	while(ADCSRA & (1<<ADSC));
	//Continuously poll the flag
	return (ADC);
}

void spi_init(void)
{
	DDRB = 0xB0; ////SCK, MOSI, and SS as outputs
	PORTB = 0x10; //Make SS high
	SPCR0 = (1<<SPE0)|(1<<MSTR0); //Enable the SPI, master mode, no interrupts
}

void spi_write(uint16_t finalData)
{
	PORTB = 0x00; //Drive SS low
	//Load control code and 4 bits of input data
	SPDR0 = (0x90)|(uint8_t)(finalData>>6);
	while((SPSR0 & 0x80) != 0x80){};
	//Load latter 6 bits of data
	SPDR0 = (uint8_t)(finalData<<2);
	while((SPSR0 & 0x80) != 0x80){};
	//Drive pin high again
	PORTB = 0x10;
}

void lcd_init(void)
{
	DDRD |= 0xCF;
	lcd_command(0x33); //Initialize LCD driver
	lcd_command(0x32); //Four bit mode
	lcd_command(0x2C); //2 Line Mode, note that the LCD has four lines, but is treated as two lines
	lcd_command(0x0C); //Display on, cursor off, blink off
	lcd_command(0x01); //Clear screen, cursor home
}

void lcd_command(char cmd)
{
	char temp = cmd;
	PORTD = 0; //Don't change the last bit to account for the ADC
	_delay_ms(5);
	cmd = ( (cmd & 0xF0) >> 4) | 0x80; //Write Upper Nibble (RS=0) E --> 1
	PORTD = cmd;
	_delay_ms(5);
	cmd ^= 0x80; //E = 0
	PORTD = cmd;
	_delay_ms(5);
	cmd = temp;
	cmd = ((cmd & 0x0F) | 0x80); //Write lower nibble (E = 1)
	PORTD = cmd;
	_delay_ms(5);
	cmd ^= 0x80;
	PORTD = cmd;
	_delay_ms(7);
	_delay_ms(20);
}

void lcd_char (char data)
{
	if (in_battle_phase == 0)
	{
		_delay_ms(500);
	}
	char temp = data;
	PORTD = 0x40;
	_delay_us(100);
	data = ( (data & 0xF0) >> 4) | 0xC0;  //Write Upper Nibble (RS=1) E --> 1
	PORTD = data;
	_delay_us(100);
	data ^= 0x80; //  E --> 0
	PORTD = data;
	_delay_us(100);
	data = temp;
	data = ( (data & 0x0F) ) | 0xC0; //Write Lower Nibble (RS=1) E --> 1
	PORTD = data;
	_delay_us(100);
	data ^= 0x80; //E --> 0
	PORTD = data;
	_delay_us(100);
}

void out_string(char s[])
{
	if (strlen(s) <=20)
	{
		for (int volatile i = 0; i < strlen(s); ++i)
		{
			lcd_char(s[i]);
		}
	}
	else if (strlen(s) <= 40)
	{
		for (int volatile i = 0; i < 20; ++i)
		{
			lcd_char(s[i]);
		}
		lcd_command(0x80+0x40); //Start on line 2
		char s1[strlen(s)-20];
		for (int volatile i = 20; i < strlen(s); ++i)
		{
			s1[i-20] = s[i];
			lcd_char(s1[i-20]);
		}
	}
	else if (strlen(s) <= 60)
	{
		
		for (int volatile i = 0; i < 20; ++i)
		{
			lcd_char(s[i]);
		}
		lcd_command(0x80+0x40); //Start on line 2
		char s1[20];
		for (int volatile i = 20; i < 40; ++i)
		{
			s1[i-20] = s[i];
			lcd_char(s1[i-20]);
		}
		lcd_command(0x80+0x14);
		char s2[strlen(s)-40];
		for (int volatile i = 40; i < strlen(s); ++i)
		{
			s2[i-40] = s[i];
			lcd_char(s2[i-40]);
		}
	}
	else if (strlen(s) <= 80)
	{
		for (int volatile i = 0; i < 20; ++i)
		{
			lcd_char(s[i]);
		}
		lcd_command(0x80+0x40); //Start on line 2
		char s1[20];
		for (int volatile i = 20; i < 40; ++i)
		{
			s1[i-20] = s[i];
			lcd_char(s1[i-20]);
		}
		lcd_command(0x80+0x14);
		char s2[strlen(s)-40];
		for (int volatile i = 40; i < 60; ++i)
		{
			s2[i-40] = s[i];
			lcd_char(s2[i-40]);
		}
		lcd_command(0x80+0x54);
		char s3[strlen(s)-60];
		for (int volatile i = 60; i < strlen(s); ++i)
		{
			s3[i-60] = s[i];
			lcd_char(s3[i-60]);
		}
	}
}

void int_to_string(unsigned long n)
{
	//Using long data type to not run into math issues with 8 bit processor
	char a[7];
	if(n == 0)
	{
		lcd_char('0');
		return;
	}
	else
	{
		itoa((int)n, a, 10);
		out_string(a);
	}
}

//For button presses, configure one timer/counter to control when data is written, and a second to 
void configure_buttons(void)
{
	//Buttons are on C0 and C1, AKA PCINT16, 17, and 18
	PCMSK2 |= (1<<PCINT16)|(1<<PCINT17)|(1<<PCINT18);
	//Enable pin change interrupt 2
	PCICR |= (1<<PCIE2);
	sei();
}

ISR(PCINT2_vect)
{
	_delay_ms(100); //Debouncing with software
	if ((PINC & (1<<PINC0)) == 0) //If the Left button is pressed
	{
		left_or_right = 1; //Left button
		while((PINC & (1<<PINC0)) == 0);
	}
	else if ((PINC & (1<<PINC1)) == 0) //If the Right button is pressed
	{
		left_or_right = 1; //Right button
		while((PINC & (1<<PINC1)) == 0);
}
else if ((PINC & (1<<PINC2)) == 0) //If the A button is pressed
{
	A = 1;
	while((PINC & (1<<PINC2)) == 0);
}
	//Clear the flag
	PCIFR = (1<<PCIF2);
	//Start writing data to DAC to generate sound to indicate button press
	TCNT1 = 0; //Set the count value equal to zero
	TCCR1B |= (1<<CS10); //Start TC1 with prescaler of 1
	//Keep track of how long data is being written for
	TCNT2 = 0; //Set the count value equal to zero
	//Change the length of the tone based upon the CdS cell value
	double volatile CdS_value = (double)ADC0_read();
	max_counts = (int)ceil((10*(30+CdS_value)/0xFFF));
	TCCR2B |= (1<<CS22)|(1<<CS21)|(1<<CS20); //Start TC2 with prescaler of 1024
}

void TC1_init(uint8_t maxValue)
{
	TCNT1 = 0; //Set the count value equal to zero
	OCR1A = maxValue;
	TCCR1A = 0; //CTC mode of operation
	TIMSK1 |= (1<<OCIE1A); //Enable the interrupt for overflow
	TCCR1B = (1<<WGM12); //CTC Mode, for now off
}

void TC2_init(void)
{
	TCNT2 = 0; //Set the count value equal to zero
	OCR2A = 0xFF; //Overflow after 0.2 seconds
	TCCR2A = 0; //CTC mode of operation
	TIMSK2 |= (1<<TOIE1); //Enable the interrupt for overflow
	TCCR2B = (1<<WGM12); //CTC Mode, for now off
}

ISR(TIMER1_COMPA_vect) //Responsible for writing data to DAC
{
	spi_write((uint16_t)((double)(sinewave[i])/20));
	i++;
}

ISR(TIMER2_OVF_vect) //Responsible for ending data writing to DAC
{
	counts = counts + 1;
	if (counts == max_counts)
	{
		TCCR1B = (1<<WGM12); //Turn off TC1
		TCCR2B = (1<<WGM12); //Turn off TC2
		counts = 0;
	}
}

void welcome(void)
{
	lcd_command(0x01); //Clear screen, cursor home
	out_string("Hello there! Welcometo the world of     Pokemon!");
	lcd_command(0x0F); //Blink cursor to indicate wait for button press
	A = 0;
	while (A == 0); //Interrupt should take care of this
	lcd_command(0x01); //Clear screen, cursor home
	out_string("This world is       inhabited by        creatures called    Pokemon!");
	lcd_command(0x0F); //Blink cursor to indicate wait for button press
	A = 0;
	while (A == 0); //Interrupt should take care of this
	lcd_command(0x01); //Clear screen, cursor home
	out_string("Your very own       Pokemon legend is   about to unfold!");
	lcd_command(0x0F); //Blink cursor to indicate wait for button press
	A = 0;
	while (A == 0); //Interrupt should take care of this
	lcd_command(0x01); //Clear screen, cursor home
	out_string("A world of dreams   and adventures with Pokemon awaits!     Let's go!");
	lcd_command(0x0F); //Blink cursor to indicate wait for button press
	A = 0;
	while (A == 0); //Interrupt should take care of this
	lcd_command(0x01); //Clear screen, cursor home
}

void select_pokemon(void)
{
	lcd_command(0x01); //Clear screen, cursor home
	out_string("Now, which Pokemon  do you want? Use theRight button to     alternate.");
	lcd_command(0x0F); //Blink cursor to indicate wait for button press
	A = 0;
	while (A == 0); //Interrupt should take care of this
	Pokemon_choice = 1; //1 for Mudkip, 2 for Treeko, 3 for Torchic
	lcd_command(0x01); //Clear screen, cursor home
	A = 0;
	left_or_right = 0;
	while (A == 0)
	{
		if (Pokemon_choice == 1)
		{
			out_string("Mudkip");
		} 
		else if (Pokemon_choice == 2)
		{
			out_string("Treeko");
		}
		else if (Pokemon_choice == 3)
		{
			out_string("Torchic");
		}
		while (left_or_right == 0) //Interrupt should take care of this
		{
			if (A == 1)
			{
				break;
			}
		}
		if (left_or_right == 1) //Left button has been pressed
		{
			lcd_command(0x01); //Clear screen, cursor home
			Pokemon_choice = Pokemon_choice - 1;
			if (Pokemon_choice == 0)
			{
				Pokemon_choice = 3;
			}
			left_or_right = 0;
		}
		if (left_or_right == 2) //Right button has been pressed
		{
			lcd_command(0x01); //Clear screen, cursor home
			Pokemon_choice = Pokemon_choice + 1;
			if (Pokemon_choice == 4)
			{
				Pokemon_choice = 1;
			}
			left_or_right = 0;
		}
	}
	lcd_command(0x01); //Clear screen, cursor home
	switch (Pokemon_choice)
	{
	case 1:
		out_string("You have chosen     Mudkip!");
		break;
	case 2:
		out_string("You have chosen     Treeko!");
		break;
	case 3:
		out_string("You have chosen     Torchic!");
		break;
	default:
		break;
	}
	lcd_command(0x0F); //Blink cursor to indicate wait for button press
	A = 0;
	while (A == 0); //Interrupt should take care of this
}

void set_stats(void)
{
	if (Pokemon_choice == 1) //Mudkip chosen
	{
		user_attack = 70;
		user_defense = 50;
		user_hp = 50;
	}
	else if (Pokemon_choice == 2) //Treeko chosen
	{
		user_attack = 45;
		user_defense = 35;
		user_hp = 40;
	}
	else //Torchic chosen	
	{
		user_attack = 60;
		user_defense = 40;
		user_hp = 45;
	}
	max_user_hp = user_hp;
	//For simplicity, let all Pokemon use tackle and growl
	//In reality, Treeko uses pound and leer
	lcd_command(0x01); //Clear screen, cursor home
	out_string("Best of luck on yourPokemon journey!");
	lcd_command(0x0F); //Blink cursor to indicate wait for button press
	A = 0;
	while(A == 0);
}

void foe_appears(void)
{
	lcd_command(0x01); //Clear screen, cursor home
	for (int volatile q = 0; q < 3; ++q)
	{
		out_string(". ");
		_delay_ms(10000);
	}
	lcd_command(0x01); //Clear screen, cursor home
	out_string("Foe Zigzagoon has   appeared!");
	A = 0;
	while (A == 0); //Interrupt should take care of this
	lcd_command(0x01); //Clear screen, cursor home
	if (Pokemon_choice == 1) //Mudkip chosen
	{
		out_string("Mudkip has been     sent out!");
	}
	else if (Pokemon_choice == 2) //Treeko chosen
	{
		out_string("Treeko has been     sent out!");
	}
	else //Torchic chosen
	{
		out_string("Torchic has been    sent out!");
	}
	A = 0;
	while (A == 0);
}

void battle_phase(void)
{
	int volatile moveChoice = 0; //Let values 0 or 1 represent move
	while ((user_hp > 0)||(foe_hp > 0))
	{
		//Adjust LEDs to represent user Pokemon health value
		if (user_hp >= (max_user_hp/2))
		{
			PORTC = 0b00110111; //Green and white LEDS on, others off
		} else if (user_hp >= (max_user_hp/4))
		{
			PORTC = 0b00101111; //Yellow and white LEDS on, others off
		}
		else
		{
			PORTC = 0b00011111; //Red and white LEDS on, others off
		}
		A = 0;
		right = 0;
		lcd_command(0x01); //Clear screen, cursor home
		moveChoice = 0;
		while (A == 0) //User's turn
		{
			//Output Foe HP
			lcd_command(0x80);
			out_string("Zigzagoon HP:");
			int_to_string((unsigned long)foe_hp); //Convert to integer and output
			out_string("/38");
			//Start a new line on row 2
			lcd_command(0x80+0x40);
			if (Pokemon_choice == 1)
			{
				out_string("Mudkip HP:");
				int_to_string((unsigned long)user_hp);
				out_string("/50");
			}
			else if (Pokemon_choice == 2)
			{
				out_string("Treeko HP:");
				int_to_string((unsigned long)user_hp);
				out_string("/40");
			}
			else
			{
				out_string("Torchic HP:");
				int_to_string((unsigned long)user_hp);
				out_string("/45");
			}
			if (user_hp <= 0)
			{
				user_hp = 0;
				break;
			}
			//Start a new line on row 4
			lcd_command(0x80+0x54);
			//Have the user select a move
			if (moveChoice == 0)
			{
				out_string("Tackle");
			}
			else
			{
				out_string("Growl ");
			}
			lcd_command(0x0F); //Blink cursor to indicate wait for button press
			if (left_or_right != 0) //If the button is pressed, display the other move option
			{
				moveChoice ^= 1; //Toggle the option
			}
			left_or_right = 0;
		}
		lcd_command(0x0C); //Display on cursor off
		//A button has been pressed, hence an attack has been chosen
		if (moveChoice == 0) //If tackle has been chosen
		{
			user_effective_attack = (user_attack/user_attack_reduction);
			damage_to_deal = (int)ceil((((4*raw_damage*user_effective_attack/foe_defense)/50)+2));
			lcd_command(0x01);
			switch (Pokemon_choice)
			{
				case 1:
				out_string("Mudkip ");
				break;
				case 2:
				out_string("Treeko ");
				break;
				case 3:
				out_string("Torchic ");
				break;
			}
			out_string("used Tackle!");
			foe_hp = floor(foe_hp - damage_to_deal);
			if (foe_hp < 0)
			{
				foe_hp = 0;
			}
		}
		else //Lower attack stat of foe
		{
			foe_attack_reduction = foe_attack_reduction + 0.5;
			lcd_command(0x01); //Clear screen, cursor home
			switch (Pokemon_choice)
			{
			case 1:
				out_string("Mudkip ");
				break;
			case 2:
				out_string("Treeko ");
				break;
			case 3:
				out_string("Torchic ");
				break;
			}
			out_string("used Growl!");
			_delay_ms(20000);
			lcd_command(0x01);
			if (foe_attack_reduction > 4)
			{
				foe_attack_reduction = 4;
				out_string("Foe Zigzagoon's");
				lcd_command(0x80+0x40);
				out_string("attack can't fall");
				lcd_command(0x80+0x14);
				out_string("any lower!");
			}
			else
			{
				out_string("Foe Zigzagoon's     attack fell!");
			}
		}
		_delay_ms(20000);
		
		//Output Foe HP
		lcd_command(0x01);
		out_string("Zigzagoon HP:");
		int_to_string((unsigned long)foe_hp); //Convert to integer and output
		out_string("/38");
		//Start a new line on row 2
		lcd_command(0x80+0x40);
		if (Pokemon_choice == 1)
		{
			out_string("Mudkip HP:");
			int_to_string((unsigned long)user_hp);
			out_string("/50");
		}
		else if (Pokemon_choice == 2)
		{
			out_string("Treeko HP:");
			int_to_string((unsigned long)user_hp);
			out_string("/40");
		}
		else
		{
			out_string("Torchic HP:");
			int_to_string((unsigned long)user_hp);
			out_string("/45");
		}
		_delay_ms(20000);
		if (foe_hp == 0)
		{
			break;
		}
		_delay_ms(20000);
		//Foe's turn
		lcd_command(0x01); //Clear screen, cursor home
		if (foe_move == 0)
		{
			foe_move ^= 1; //Toggle the move that the foe uses
			foe_effective_attack = (foe_attack/foe_attack_reduction);
			damage_to_deal = (int)ceil((((3.2*raw_damage*foe_effective_attack/user_defense)*1.5/50)+2));
			out_string("Foe Zigzagoon used  Tackle!");
			user_hp = floor(user_hp - damage_to_deal);
		}
		else
		{
			foe_move ^= 1; //Toggle the move that the foe uses
			user_attack_reduction = user_attack_reduction + 0.5;
			out_string("Foe Zigzagoon used  Growl!");
			_delay_ms(20000);
			lcd_command(0x01); //Clear screen, cursor home
			if (user_attack_reduction > 4)
			{
				user_attack_reduction = 4;
				switch (Pokemon_choice)
				{
					case 1:
					out_string("Mudkip's ");
					break;
					case 2:
					out_string("Treeko's ");
					break;
					case 3:
					out_string("Torchic's ");
					break;
				}
				out_string("attack");
				lcd_command(0x80+0x40);
				out_string("can't fall any");
				lcd_command(0x80+0x14);
				out_string("lower!");
			}
			else
			{
				switch (Pokemon_choice)
				{
					case 1:
					out_string("Mudkip's ");
					break;
					case 2:
					out_string("Treeko's ");
					break;
					case 3:
					out_string("Torchic's ");
					break;
				}
				out_string("attack");
				lcd_command(0x80+0x40);
				out_string("fell!");
			}
		}
		_delay_ms(20000);
	}
	//Output Foe HP
	lcd_command(0x80);
	out_string("Zigzagoon HP:");
	int_to_string((unsigned long)foe_hp); //Convert to integer and output
	out_string("/38");
	//Start a new line on row 2
	lcd_command(0x80+0x40);
	if (Pokemon_choice == 1)
	{
		out_string("Mudkip HP:");
		int_to_string((unsigned long)user_hp);
		out_string("/50");
	}
	else if (Pokemon_choice == 2)
	{
		out_string("Treeko HP:");
		int_to_string((unsigned long)user_hp);
		out_string("/40");
	}
	else
	{
		out_string("Torchic HP:");
		int_to_string((unsigned long)user_hp);
		out_string("/45");
	}
	
	//Either the user Pokemon has fainted or the opponent Pokemon has fainted
	if (user_hp == 0)
	{
		lcd_command(0x01); //Clear screen, cursor home
		out_string("Your Pokemon has    fainted! Sorry,     reset to try again!");
	}
	else
	{
		lcd_command(0x01); //Clear screen, cursor home
		out_string("Foe Zigzagoon has   fainted! Reset to   play again!");
	}
}