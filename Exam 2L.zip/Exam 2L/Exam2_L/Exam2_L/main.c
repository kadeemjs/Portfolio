/*
 * Exam2_L.c
 *
 * Created: 8/7/2018 9:27:51 AM
 * Author : Kadeem
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

