/*
 * FunctionGenerator.c
 *
 * Created: 10/3/2018 8:25:26 AM
 * Author : Kadeem
 */ 

#define F_CPU 98000 //1 MHz system clock

#include <avr/io.h>
#include <util/delay.h>

//Table for sine values
const uint16_t sineTable[] = {
	0x200,0x232,0x264,0x295,0x2c4,0x2f1,0x31c,0x345,
	0x36a,0x38c,0x3aa,0x3c4,0x3d9,0x3ea,0x3f6,0x3fe,
	0x3ff,0x3fe,0x3f6,0x3ea,0x3d9,0x3c4,0x3aa,0x38c,
	0x36a,0x345,0x31c,0x2f1,0x2c4,0x295,0x264,0x232,
	0x200,0x1ce,0x19c,0x16b,0x13c,0x10f,0xe4,0xbb,
	0x96,0x74,0x56,0x3c,0x27,0x16,0xa,0x2,
	0x0,0x2,0xa,0x16,0x27,0x3c,0x56,0x74,
	0x96,0xbb,0xe4,0x10f,0x13c,0x16b,0x19c,0x1ce
	};

const uint16_t squareTable[] = {
	0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
	0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
	0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
	0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
	0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,
	0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,
	0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,
	0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,0x3ff,
	0x3ff,0x3ff,0x3ff,0x3ff
	};
const uint16_t triangleTable[] = {
	0x20,0x40,0x60,0x80,0xa0,0xc0,0xe0,0x100,
	0x120,0x140,0x160,0x180,0x1a0,0x1c0,0x1e0,0x200,
	0x220,0x240,0x260,0x280,0x2a0,0x2c0,0x2e0,0x300,
	0x320,0x340,0x360,0x380,0x3a0,0x3c0,0x3e0,0x3ff,
	0x3e0,0x3c0,0x3a0,0x380,0x360,0x340,0x320,0x300,
	0x2e0,0x2c0,0x2a0,0x280,0x260,0x240,0x220,0x200,
	0x1e0,0x1c0,0x1a0,0x180,0x160,0x140,0x120,0x100,
	0xe0,0xc0,0xa0,0x80,0x60,0x40,0x20,0x0
	};
const uint16_t sawtoothTable[] = {
	0x0,0x10,0x20,0x30,0x40,0x50,0x60,0x70,0x80,
	0x90,0xa0,0xb0,0xc0,0xd0,0xe0,0xf0,0x100,
	0x110,0x120,0x130,0x140,0x150,0x160,0x170,0x180,
	0x190,0x1a0,0x1b0,0x1c0,0x1d0,0x1e0,0x1f0,0x200,
	0x210,0x220,0x230,0x240,0x250,0x260,0x270,0x280,
	0x290,0x2a0,0x2b0,0x2c0,0x2d0,0x2e0,0x2f0,0x300,
	0x310,0x320,0x330,0x340,0x350,0x360,0x370,0x380,
	0x390,0x3a0,0x3b0,0x3c0,0x3d0,0x3e0,0x3f0
	};

//Using ADC0 for voltage reference, and ADC1 for frequency
void ADC_init(void);
uint16_t ADC0_read(void);
uint16_t ADC1_read(void);
void spi_init(void);
void spi_write(uint16_t finalData);
void delays(int delayTime);

//Global variables
/*Use two switches to determine the waveform
	0b00: Sine wave
	0b01: Square wave
	0b10: Triangle wave
	0b11: Sawtooth wave
*/
//Amplitude is between 1 and 5
//Vary value of ampShift between 0 and 4 based upon ADC1
//Add 1, and divide the lookup value by this
double volatile amplitude = 2;
double volatile ampShift = 0;
//Frequency varies from 10Hz to 100Hz
//Vary value of freqShift between 0 and 90 based upon ADC0
//Add 10, and divide the lookup value by this
double volatile period = 58;
double volatile freqShift = 0;
int volatile peak = 64;
int main(void)
{
	
	//Variable to know when interrupt occurred
	uint8_t volatile counter = 0;
	uint8_t volatile counter2 = 0;
	double volatile fShift = 0;
	double volatile aShift = 0;
	DDRD = 0; //Use PortD as an input for the switches, on 0 and 1
	spi_init(); //Initialize SPI
	ADC_init(); //Initialize ADC
	double volatile data = 0;
	int volatile delayTime = 0;
	fShift = ADC0_read();
	freqShift = (period + period*(fShift/1024));
	delayTime = (int)(freqShift);
	aShift = ADC1_read();
	ampShift = (uint16_t)(amplitude + 4*(aShift/1024));
	uint16_t volatile finalData = (uint16_t)(data / ampShift);
	uint8_t volatile switches = 0;
    while (1) 
    {
		if(counter2 == 150)
		{
			counter2 = 0;
			fShift = ADC0_read();
			freqShift = (period*(1 + 15*((fShift-25)/1024)));
			delayTime = (int)(freqShift);
			aShift = ADC1_read();
			ampShift = (1 + 5*(aShift/1024));
		}
		switches = PIND;
		switch (switches)
		{
		case 0x00:
			data = sineTable[counter];
			break;
		case 0x01:
			data = squareTable[counter];
			break;
		case 0x02:
			data = triangleTable[counter];
			break;
		case 0x03:
			data = sawtoothTable[counter];
			break;
		default:
			break;
		}
		finalData = (uint16_t)(data / ampShift);
		++counter;
		++counter2;
		spi_write(finalData);
		if (counter == peak)
		{
			counter = 0;
		}
		if(switches == 0x01)
		{
			delays(delayTime+14);
		} else {
			delays(delayTime);
		}
	}
}

void delays(int delayTime)
{
	while (0 < delayTime)
	{
		_delay_us(82);
		--delayTime;
	}
}

void spi_init(void)
{
	DDRB = 0xB0; ////SCK, MOSI, and SS as outputs
	PORTB = 0x10; //Make SS high
	SPCR0 = (1<<SPE0)|(1<<MSTR0); //Enable the SPI, master mode, no interrupts
}

void spi_write(uint16_t finalData)
{
	uint8_t volatile data = 0;
	PORTB = 0x00; //Drive SS low
	//Load control code and 4 bits of input data
	SPDR0 = (0x90)|(uint8_t)(finalData>>6);
	while((SPSR0 & 0x80) != 0x80);
	//Load latter 6 bits of data
	data = SPDR0;
	SPDR0 = (uint8_t)(finalData<<2);
	while((SPSR0 & 0x80) != 0x80);
	data = SPDR0;
	//Drive SS pin high again
	PORTB = 0x10;
}

void ADC_init(void)
{
	DDRA = 0x80; //PA is all inputs
	DIDR0 = (1<<ADC0D); //Disable digital input buffer on PA0 to reduce power consumption
	ADMUX = (1<<REFS0)|(0x0); //AVcc pin as reference, right adjusted format, gain of 1, using ADC0
	ADCSRA |= (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(ADPS0); //Enable the ADC, and start the first conversion, prescaler of 128
}

//For frequency
uint16_t ADC0_read(void)
{
	ADMUX = (1<<REFS0)|(0x0); //Using ADC0
	ADCSRA |= (1<<ADSC);
	while(ADCSRA & (1<<ADSC));
	//Continuously poll the flag
	return (ADC);
}

//For amplitude
uint16_t ADC1_read(void)
{
	ADMUX = (1<<REFS0)|(0x1); //Using ADC1
	ADCSRA |= (1<<ADSC);
	while(ADCSRA & (1<<ADSC));
	//Continuously poll the flag
	return (ADC);
}