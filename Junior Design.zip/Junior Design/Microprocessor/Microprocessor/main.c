/*
 * Microprocessor.c
 *
 * Created: 8/27/2018 1:47:53 PM
 * Author : Kadeem
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

