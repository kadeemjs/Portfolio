/*
 * Ohmmeter Part 1.c
 *
 * Created: 8/25/2018 5:51:27 PM
 * Author : Kadeem Samuel
 * 
 * The purpose of this program is to use a switch to either flash an LED at 2 Hz or output a 2 kHz wave to a speaker
 */ 

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRB = 0x01; //Set Pin0 on PORTB as an output
	DDRA = 0x00; //Pin0 on PORTA as an input
	DDRD = 0x01; //Set Pin0 on PORTD as an output
    //Square wave is simply outputting either a 1 or a 0
    while (1) 
    {
		if (PINA == 0)
		{
			PORTB = 0;
			_delay_us(247);
			PORTD = 1;
			_delay_us(247);
			PORTD = 0;
		}
		else
		{
			_delay_ms(250);
			PORTB = 1;
			_delay_ms(250);
			PORTB = 0;
		}
    }
}

