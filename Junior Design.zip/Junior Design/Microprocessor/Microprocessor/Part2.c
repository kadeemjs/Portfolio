/*
 * Part2.c
 *
 * Created: 8/29/2018 4:55:48 PM
 *  Author: Kadeem Samuel
 *
 * The purpose of this program is to measure the resistance of a resistor, and display the resistance on an LCD screen
 */ 

#include <avr/io.h>
#include <util/delay.h>

void ADC_init(void);
void lcd_init(void);
void lcd_command(char);
void lcd_char(char);
void out_string(char s[]);
void int_to_string(unsigned long n);
uint16_t ADC_read(void);

//Math will be done in kOhms due to processor data size (8 bit), then numbers will be fed to LCD in Ohms
double volatile Rl = 9820.0; //Known resistance value, used in voltage divider, measured in kOhms
unsigned long volatile Rmeas = 0;//
char resistance[0];

int main (void)
{
	uint16_t volatile ADCValue = 0;
	ADC_init();
	lcd_init();
	while (1)
	{
		lcd_command(0x01); //Clear the LCD
		for(int volatile i = 1; i <= 5; ++i)
		{
			ADCValue += (uint16_t)(ADC_read()-1); //Store the value from the ADC, -1 used as a correction factor
		}
		ADCValue = ADCValue/5;
		float volatile Voltage = (ADCValue * (5.0/1024.0)); //Determine the voltage value
		Rmeas = (unsigned long)(Voltage * Rl)/(5.0 - Voltage); //Measure the resistance value
		//The following are correction factors to account for inaccuracies made in different voltage ranges by the ADC:
		if(Rmeas < 800 || Rmeas > 1200000) //Values Shiming told me to use
		{
			out_string("OUT OF RANGE");
		} 
		else
		{
			Rmeas = 1.001*Rmeas;
			out_string("R = ");
			int_to_string(Rmeas);
			out_string(" Ohms");
		}
		_delay_ms(750); //Delay so that the full message can appear on the LCD
		ADCValue = 0;
	}
}

void ADC_init(void)
{
	DDRA = 0x00; //PA is all inputs
	DIDR0 = (1<<ADC0D); //Disable digital input buffer on PA0 to reduce power consumption
	ADMUX = (1<<REFS0); //AVcc pin as reference, right adjusted format, gain of 1, using ADC0
	ADCSRA |= (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(ADPS0); //Enable the ADC, and start the first conversion, prescaler of 128
}

uint16_t ADC_read(void)
{
	ADCSRA |= (1<<ADSC);
	while(ADCSRA & (1<<ADSC));
	//Continuously poll the flag
	return (ADC);
}

void lcd_init(void)
{
	DDRD |= 0xCF;
	lcd_command(0x33); //Initialize LCD driver
	lcd_command(0x32); //Four bit mode
	lcd_command(0x2C); //2 Line Mode
	lcd_command(0x0C); //Display on, cursor off, blink off
	lcd_command(0x01); //Clear screen, cursor home
}

void lcd_command(char cmd)
{
	char temp = cmd;
	PORTD = 0; //Don't change the last bit to account for the ADC
	_delay_ms(5);
	cmd = ( (cmd & 0xF0) >> 4) | 0x80; //Write Upper Nibble (RS=0) E --> 1
	PORTD = cmd;
	_delay_ms(5);
	cmd ^= 0x80; //E = 0
	PORTD = cmd;
	_delay_ms(5);
	cmd = temp;
	cmd = ((cmd & 0x0F) | 0x80); //Write lower nibble (E = 1)
	PORTD = cmd;
	_delay_ms(5);
	cmd ^= 0x80;
	PORTD = cmd;
	_delay_ms(7);
}

void lcd_char (char data)
{
	char temp = data;
	PORTD = 0x40;
	_delay_us(100);
	data = ( (data & 0xF0) >> 4) | 0xC0;  //Write Upper Nibble (RS=1) E --> 1
	PORTD = data;
	_delay_us(100);
	data ^= 0x80; //  E --> 0 
	PORTD = data;
	_delay_us(100);
	data = temp;
	data = ( (data & 0x0F) ) | 0xC0; //Write Lower Nibble (RS=1) E --> 1
	PORTD = data;
	_delay_us(100);
	data ^= 0x80; //E --> 0 
	PORTD = data;
	_delay_us(100);
}

void out_string(char s[])
{
	for (int volatile i = 0; i < strlen(s); ++i)
	{
		lcd_char(s[i]);
	}
}

void int_to_string(unsigned long n)
{
	//Using long data type to not run into math issues with 8 bit processor
	char a[7] = {0};
	int volatile i=0;
	if(n == 0)
	{
		//Case where the voltage is shorted
		lcd_char('0');
		return;
	}
	else

	{
		while(n > 0)
		{
			//Add the number at each location to the char form of 0, to generate char integers
			a[i++] = (n % 10) + '0';
			n = n / 10;
		}
		out_string(a);
	}
}