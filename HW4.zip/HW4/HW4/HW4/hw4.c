/*
 * HW4.c
 *
 * Created: 7/20/2018 5:12:51 PM
 * Author : Kadeem
 * The purpose of this program is to output a 4 MHz clock to PORTC pin7.
 */ 

#include <avr/io.h>

extern void clock_init(void);

int main(void)
{
    clock_init();
    PORTC.DIR = PIN7_bm; //Set pin7 as an output pin
	CCP = CCP_IOREG_gc;
    CLK.PSCTRL = CLK_PSADIV_8_gc; //Set the /8 prescaler, for 4 MHz clock
	PORTCFG.CLKEVOUT = PORTCFG_CLKOUT_PC7_gc; //Output the clock on pin7 of PORTCs
    while (1) 
    {
    }
}