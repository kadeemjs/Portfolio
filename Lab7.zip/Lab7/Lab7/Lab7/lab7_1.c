/*
 * Lab7.c
 *
 * Created: 8/2/2018 7:05:48 PM
 * Author : Kadeem
 * The purpose of this program is to continually write the voltage value of each DIP switch to a corresponding LED on the LED bank.
 */ 

#include <avr/io.h>
#include "ebi_driver.h"

void EBI_init(void);

int main(void)
{
    //Pointer and variable for I/O port
	//Initialize EBI
 	EBI_init();
	uint8_t mem_value = 0;
    while (1) 
    {
			mem_value = __far_mem_read(0x0692FF);
			asm("nop");
			__far_mem_write(0x0692FF, mem_value);
    }
}

void EBI_init(void)
{
	//Enable RE, WE, CS0, CS1, and ALE1
	PORTH.DIR = PIN5_bm|PIN4_bm|PIN2_bm|PIN1_bm|PIN0_bm; 
	//Set the active low pins to by high by default
	PORTH.OUT = PIN5_bm|PIN4_bm|PIN1_bm|PIN0_bm; 
	//Enable the address line outputs
	PORTK.DIR = PIN7_bm|PIN6_bm|PIN5_bm|PIN4_bm|PIN3_bm|PIN2_bm|PIN1_bm|PIN0_bm;
	//PortJ is an input port by default
	//SRAM mode, using only ALE1, with three ports (H, J, and K) enabled
	EBI.CTRL = EBI_SRMODE_ALE1_gc|EBI_IFMODE_3PORT_gc;
	//Load the starting address of the I/O ports into BASEADDR for CS0
	EBI.CS1.BASEADDR = 0x0690;
	EBI.CS1.CTRLA = EBI_CS_MODE_SRAM_gc|EBI_CS_ASPACE_1KB_gc;
}